"""Regression tests for the real-vehicle validation cases (validation/*.yaml). Published figures and sources are listed in tools/run_validation.py.
These tests pin the *documented* agreement levels; they are not proof of predictive accuracy."""
import math
import os
import pytest
from helpers import ROOT, ASSUMP
from launch_vehicle.config_io import load_design
from launch_vehicle.convergence import size_vehicle
from launch_vehicle.units import G0

V = lambda n: os.path.join(ROOT, "validation", n + ".yaml")
LEAN = lambda N, fr=None: dict({f"stages.{j}.{k}": v for j in range(N) for k, v in (("residual_fraction", 0.01), ("loading_margin_fraction", 0.0), ("inert_mass_margin_fraction", 0.0))},
                               **({"vehicle.dv_fractions": fr} if fr else {}))


def test_all_validation_cases_converge_without_hard_errors():
    for n in ("electron", "falcon9", "titan2", "saturn5", "zhuque2", "combo_kerolox", "combo_methalox", "combo_hydrolox", "combo_kerolox_hydrolox", "combo_hypergolic"):
        r = size_vehicle(load_design(V(n), ASSUMP))
        assert r.converged, n
        assert not [i for i in r.issues if i.level == "ERROR"], (n, [str(i) for i in r.issues if i.level == "ERROR"])
        assert sum(s.dv_check_mps for s in r.stages) == pytest.approx(r.dv_required_mps, abs=1e-4)


def test_saturn_v_with_book_dv_split_matches_published_gross_mass_within_5_percent():
    # Basis: Wikipedia 2,822,171-2,965,241 kg; dv split from Book Example 5.1. (Model result: about -2 %.)
    r = size_vehicle(load_design(V("saturn5"), ASSUMP))
    assert r.glom_kg == pytest.approx(2894000.0, rel=0.05)
    assert 12000.0 < r.dv_required_mps < 12800.0                    # book Example 5.1 ideal sum 12,133 m/s plus losses/rotation


def test_falcon_9_and_titan_ii_with_lean_margins_within_8_percent():
    # Diagnostic (not calibration): with 1 % residual, no loading margin and no mass-growth margin, as in operational vehicles.
    f9 = size_vehicle(load_design(V("falcon9"), ASSUMP, LEAN(2, [0.40, 0.60])))
    assert f9.glom_kg == pytest.approx(549054.0, rel=0.08)
    t2 = size_vehicle(load_design(V("titan2"), ASSUMP, LEAN(2, [0.38, 0.62])))
    assert t2.glom_kg == pytest.approx(154000.0, rel=0.08)


def test_default_margins_make_the_model_conservative_versus_real_vehicles():
    # With the book's 2 % residual + 0.5 % margin + 10 % mass-growth margin the prediction exceeds the published GLOM for these vehicles.
    for n, pub in (("falcon9", 549054.0), ("titan2", 154000.0), ("electron", 13000.0)):
        assert size_vehicle(load_design(V(n), ASSUMP)).glom_kg > pub


def test_delta_v_regression_is_consistent_with_published_stage_masses():
    # Ideal dv of the published Falcon 9 and Titan II stage masses is within +/-5 % of the book-regression requirement for their missions.
    def ideal(stages, payload):
        tot = 0.0
        for k, (p, i, e) in enumerate(stages):
            above = payload + sum(pp + ii for pp, ii, _ in stages[k + 1:])
            tot += G0 * e * math.log((above + i + p) / (above + i))
        return tot
    f9 = ideal([(395700, 25600, (285 + 2 * 313) / 3), (107500, 3900, 348)], 22800)
    t2 = ideal([(117800, 6700, (258 + 2 * 296) / 3), (28900, 2400, 316)], 3574)
    rf = size_vehicle(load_design(V("falcon9"), ASSUMP))
    rt = size_vehicle(load_design(V("titan2"), ASSUMP))
    assert f9 == pytest.approx(rf.dv_required_mps, rel=0.05)
    assert t2 == pytest.approx(rt.dv_required_mps, rel=0.05)


def test_book_example_5_1_saturn_v_ideal_speed_reproduced():
    # Basis: Book Example 5.1 (p.283-284): ideal speed 3,099 + 4,775 + 4,259 = 12,133 m/s
    st = [(2080e3, 240e3, 263), (450e3, 36e3, 419), (108e3, 11e3, 426)]
    tot, pl = 0.0, 50e3
    for k, (p, i, e) in enumerate(st):
        above = pl + sum(pp + ii for pp, ii, _ in st[k + 1:])
        tot += G0 * e * math.log((above + i + p) / (above + i))
    assert tot == pytest.approx(12133.0, rel=2e-3)


def test_propellant_type_ordering_on_the_same_mission():
    # Physics expectation: higher Isp (LH2 > CH4 > RP-1 > hypergolic) gives lower gross mass for the same payload/orbit/stage count.
    g = {n: size_vehicle(load_design(V("combo_" + n), ASSUMP)).glom_kg for n in ("hydrolox", "kerolox_hydrolox", "methalox", "kerolox", "hypergolic")}
    assert g["hydrolox"] < g["kerolox_hydrolox"] < g["methalox"] < g["kerolox"] < g["hypergolic"]
    # dv requirements are consistent across combinations (same mission): within 2 % (they differ only through burn time in the regression)
    dvs = [size_vehicle(load_design(V("combo_" + n), ASSUMP)).dv_required_mps for n in g]
    assert max(dvs) / min(dvs) < 1.02


# ---------------------------------------------------------------- v0.3: solids, strap-ons and small launchers
#: every serial-solid check case. These are the ones that exercise the solid mass model, as opposed to the
#: BOOSTED_CASES below, whose booster masses are published inputs and so test the phase model instead.
SOLID_CASES = ("pegasus_xl", "vega", "epsilon", "scout_g1", "vega_c", "m_v")
BOOSTED_CASES = ("delta2_7920", "atlas5_551", "ariane5_eca")


#: Cases that converge but whose AS-PUBLISHED split produces a design the tool then refuses to build.
#:
#: This is not a test being relaxed to pass. The errors are correct outputs. The tool sizes these vehicles
#: 40-60% too heavy (docs/ACCURACY.md section 2), it computes each nozzle from the thrust the SIZED vehicle
#: needs, and a nozzle sized for a 54 t Scout does not fit on a 1.14 m case. The geometry error is a true
#: statement about the oversized design, and suppressing it by lowering an assumed expansion ratio would
#: hide the oversizing rather than fix it. What is asserted for these is that they converge, close their
#: delta-v, and produce only the geometry errors that follow from being too heavy - never a mass or
#: propellant error, which would mean something different was wrong.
OVERSIZED_GEOMETRY = {"scout_g1": {"ENGFIT"}, "m_v": {"ENGFIT"}}


def test_v03_validation_cases_converge_without_hard_errors():
    for n in SOLID_CASES + BOOSTED_CASES + ("firefly_alpha",):
        r = size_vehicle(load_design(V(n), ASSUMP))
        assert r.converged, n
        errs = [i for i in r.issues if i.level == "ERROR"]
        allowed = OVERSIZED_GEOMETRY.get(n, set())
        unexpected = [str(i) for i in errs if i.code not in allowed]
        assert not unexpected, (n, unexpected)
        if allowed:
            assert errs, (f"{n} is listed in OVERSIZED_GEOMETRY but no longer produces those errors - if the "
                          "mass model improved enough to fix it, take it off the list")
        assert sum(s.dv_check_mps for s in r.stages) == pytest.approx(r.dv_required_mps, abs=1e-3), n


def test_boosted_vehicles_close_their_mass_and_phase_budgets():
    from launch_vehicle.boosters import total_dv
    for n in BOOSTED_CASES:
        r = size_vehicle(load_design(V(n), ASSUMP))
        b = r.boosters
        assert b is not None, n
        total = (r.payload_mass_kg + r.paf_mass_kg + r.fairing_mass_kg + b.m_total_kg
                 + sum(s.m_dry_kg + s.m_prop_loaded_kg for s in r.stages))
        assert total == pytest.approx(r.glom_kg, rel=1e-12), n
        s1 = r.stages[b.attach_stage - 1]
        assert total_dv(s1.phases) == pytest.approx(s1.dv_mps, rel=1e-6), n
        assert s1.burn_time_s > b.burn_time_s, n                      # the core must outlast the strap-ons


def test_delta_ii_air_lit_boosters_produce_three_powered_phases():
    r = size_vehicle(load_design(V("delta2_7920"), ASSUMP))
    assert r.boosters.n_ground_lit == 6 and r.boosters.n_total == 9
    powered = [p for p in r.stages[0].phases if p.duration_s > 0]
    assert len(powered) == 3
    assert "ground-lit" in powered[0].name and "air-lit" in powered[1].name


def test_solid_casing_mer_is_conservative_against_real_motors():
    """Documented finding: the book's SRM casing MER (Eq. 8:18) predicts a heavier motor than modern
    filament-wound hardware. Published inert/propellant ratios: Pegasus XL 0.091/0.106/0.164, Vega 0.083/0.081/0.087."""
    published = {"pegasus_xl": [1369 / 15014, 416 / 3925, 126 / 770], "vega": [7330 / 88365, 1950 / 24000, 915 / 10500]}
    from launch_vehicle.solid_motor import K_SRM
    for name, ks in published.items():
        for k in ks[:2]:                                              # the big lower stages
            assert K_SRM["composite"] > k                             # the MER is heavier than the real motor
    r = size_vehicle(load_design(V("vega"), ASSUMP))
    s_pred = r.stages[0].structural_factor_s
    s_pub = 7330.0 / (7330.0 + 88365.0)
    assert 1.3 < s_pred / s_pub < 1.8                                 # about +50 %, as reported in the validation report


def test_air_launch_credit_reduces_the_requirement_and_needs_user_losses():
    from launch_vehicle.validation import InputError
    r = size_vehicle(load_design(V("pegasus_xl"), ASSUMP))
    line = [l for l in r.budget.lines if "Air-launch" in l.name]
    assert len(line) == 1 and line[0].value_mps < 0
    assert r.dv_required_mps < 8600.0                                 # below a comparable ground launch
    with pytest.raises(InputError, match="air-launched"):
        size_vehicle(load_design(V("pegasus_xl"), ASSUMP, {"mission.losses.model": "book_penalty"}))


def test_small_launchers_are_over_predicted_but_the_calibrated_run_is_close():
    """Vega with each motor's published casing ratio lands within 10 % of the real vehicle."""
    N = 4
    ov = {f"stages.{j}.motor.casing_mass_method": "mass_fraction" for j in range(3)}
    ov.update({f"stages.{j}.motor.casing_mass_fraction": k for j, k in
               ((0, 7330 / 88365), (1, 1950 / 24000), (2, 915 / 10500))})
    ov.update({f"stages.{j}.inert_mass_margin_fraction": 0.0 for j in range(N)})
    ov["vehicle.dv_fractions"] = [0.2205, 0.1796, 0.2088, 0.3910]     # GLOM-minimising split from optimize_dv_split()
    r = size_vehicle(load_design(V("vega"), ASSUMP, ov))
    assert r.glom_kg == pytest.approx(137000.0, rel=0.10)
