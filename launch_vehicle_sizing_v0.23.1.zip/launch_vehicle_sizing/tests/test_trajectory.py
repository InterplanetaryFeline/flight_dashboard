"""The 3-DoF ascent trajectory, its atmosphere and its aerodynamics (book Chapter 6).

Three kinds of check here. First, the pieces against published numbers: US Standard Atmosphere 1976 to five
figures, and the book's own Titan II drag equations at their breakpoints. Second, the integration against
itself: the four losses plus the final speed must reconstruct the vacuum ideal delta-v exactly, which is the one
identity that catches almost any mistake in the loss accounting. Third, the whole thing against the book's own
expectations for a good trajectory (p.379): max-q between 50 and 90 s, a smooth 90 -> 0 deg flight path angle,
gravity loss near 1.5 km/s and drag loss of 100-200 m/s.
"""
import math
import os
import pytest
from helpers import *                                        # noqa: F401,F403
from launch_vehicle import atmosphere as atm, aerodynamics as aero, trajectory as tj
from launch_vehicle.config_io import load_design
from launch_vehicle.convergence import size_vehicle

_C = {}


def flown():
    """The default design, flown once (every trajectory test but the failure cases reuses it)."""
    if "r" not in _C:
        _C["r"] = default_result()
        _C["t"] = tj.fly_design(_C["r"], dt=0.25)
    return _C["r"], _C["t"]


# ------------------------------------------------------------------ atmosphere
def test_us76_reproduces_the_published_layer_values():
    """The 1976 standard's own defining values at each layer base, entered as geopotential altitudes."""
    def geometric(hp):
        return atm.R_EARTH_US76 * hp / (atm.R_EARTH_US76 - hp)
    published = {0: (288.15, 101325.0), 11000: (216.65, 22632.1), 20000: (216.65, 5474.89),
                 32000: (228.65, 868.019), 47000: (270.65, 110.906), 71000: (214.65, 3.95642)}
    for hp, (T, p) in published.items():
        a = atm.us76(geometric(hp))
        assert a.temperature_K == pytest.approx(T, rel=1e-5), hp
        assert a.pressure_Pa == pytest.approx(p, rel=1e-4), hp


def test_us76_sea_level_density_and_sound_speed():
    a = atm.us76(0.0)
    assert a.density_kg_m3 == pytest.approx(1.225, rel=1e-4)
    assert a.sound_speed_mps == pytest.approx(340.29, rel=1e-3)


def test_book_exponential_is_the_book_formula():
    """Eqs. 6:50 and 6:53 with h0 = 7.64 km, and the pressure and density falling by the same factor."""
    for h in (0.0, 5000.0, 20000.0):
        a = atm.book_exponential(h)
        k = math.exp(-h / 7640.0)
        assert a.density_kg_m3 == pytest.approx(1.225 * k, rel=1e-12)
        assert a.pressure_Pa == pytest.approx(101325.0 * k, rel=1e-12)


def test_the_book_scale_height_is_within_a_quarter_of_the_standard_atmosphere():
    """A sanity bound on the approximation the book asks for: a single scale height cannot match a layered
    atmosphere everywhere, but it must not be wildly off where the drag is."""
    for h in (10000.0, 20000.0, 30000.0):
        eq = atm.scale_height_from_models(h)
        assert 0.75 < eq / atm.SCALE_HEIGHT_M < 1.30, (h, eq)


def test_gravity_falls_with_the_inverse_square():
    assert atm.gravity_mps2(0.0) == pytest.approx(9.80665, rel=1e-12)
    assert atm.gravity_mps2(400e3) == pytest.approx(9.80665 / (1 + 400e3 / 6378e3) ** 2, rel=1e-12)


def test_an_unknown_atmosphere_model_is_refused():
    with pytest.raises(ValueError):
        atm.air(0.0, "exponential-ish")


# ------------------------------------------------------------------ aerodynamics
def test_titan2_drag_matches_the_printed_equations_and_is_continuous():
    """Book Fig. 6.13: Cd = 0.29 to M 0.8, then M - 0.51, then 0.091 + 0.5/M above M 1.068."""
    assert aero.cd_titan2(0.0) == 0.29 and aero.cd_titan2(0.8) == pytest.approx(0.29)
    assert aero.cd_titan2(1.0) == pytest.approx(0.49, rel=1e-12)
    # the printed breakpoint 1.068 is the rounded root of the two branches (the exact crossing is 1.06882), so
    # the curve has a step of about 0.0012 there. That is the book's rounding, and it is reproduced rather than
    # smoothed away; the test pins its size so it cannot grow.
    lo, hi = aero.cd_titan2(1.068 - 1e-9), aero.cd_titan2(1.068 + 1e-9)
    assert abs(hi - lo) < 0.002, (lo, hi)
    assert aero.cd_titan2(aero.CD_TITAN2_EXACT_JOIN_MACH - 1e-9) == pytest.approx(
        aero.cd_titan2(aero.CD_TITAN2_EXACT_JOIN_MACH + 1e-9), rel=1e-5)
    assert aero.cd_titan2(1.068) == pytest.approx(0.558, abs=0.001)
    assert aero.cd_titan2(8.0) == pytest.approx(0.091 + 0.5 / 8.0, rel=1e-12)


def test_the_drag_curve_has_the_transonic_peak_every_book_figure_shows():
    samples = [(m / 20.0, aero.cd_titan2(m / 20.0)) for m in range(1, 161)]
    peak_m = max(samples, key=lambda s: s[1])[0]
    assert 0.9 < peak_m < 1.3, peak_m
    assert aero.cd_titan2(6.0) < aero.cd_titan2(peak_m) / 2


def test_constant_and_table_models():
    assert aero.constant_model(0.25).cd(3.0) == 0.25
    t = aero.table_model([0.0, 1.0, 5.0], [0.2, 0.6, 0.25])
    assert t.cd(0.5) == pytest.approx(0.4)
    assert t.cd(-1.0) == 0.2 and t.cd(99.0) == 0.25     # clamped, never extrapolated
    with pytest.raises(ValueError):
        aero.table_model([1.0], [0.3])


# ------------------------------------------------------------------ the ZOOM file format
ZOOM_MINIMAL = """A TEST FILE
///

len units       m
alt units      km
ang units     deg

     sref     10.0

   mach #      0.     1.0     5.0
 altitude      0.    20.0
  alphamd     0.0     0.0     0.0
             0.0     0.0     0.0
 cdmin-on     0.2     0.5     0.2
            0.18     0.45    0.18
cdmin-off     0.3     0.6     0.3
            0.28     0.55    0.28
"""


def test_zoom_reader_parses_units_tables_and_reference_area():
    p = aero.parse_zoom_ld(ZOOM_MINIMAL)
    assert p["descriptor"] == "A TEST FILE"
    assert p["sref_m2"] == pytest.approx(10.0)
    g = p["groups"][0]
    assert g["mach"] == [0.0, 1.0, 5.0]
    assert g["altitude_m"] == [0.0, 20000.0]             # km converted to metres
    assert len(g["vars"]["cdmin-on"]) == 2               # one row per altitude


def test_zoom_model_interpolates_in_mach_and_altitude_and_clamps():
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "t.dat")
        open(path, "w").write(ZOOM_MINIMAL)
        m = aero.read_zoom_ld_file(path)
    assert m.cd(1.0, 0.0, power_on=True) == pytest.approx(0.5)
    assert m.cd(1.0, 0.0, power_on=False) == pytest.approx(0.6)
    assert m.cd(1.0, 20000.0, power_on=True) == pytest.approx(0.45)
    assert m.cd(1.0, 10000.0, power_on=True) == pytest.approx(0.475)      # bilinear
    assert m.cd(99.0, 0.0) == pytest.approx(0.2)                          # clamped above the table
    assert m.has_power_split


def test_a_file_without_the_slash_record_is_refused():
    with pytest.raises(aero.ZoomFileError):
        aero.parse_zoom_ld("just some text\nwith no formatted section\n")


def test_a_row_with_the_wrong_number_of_values_is_refused():
    bad = ZOOM_MINIMAL.replace(" cdmin-on     0.2     0.5     0.2", " cdmin-on     0.2     0.5")
    with pytest.raises(aero.ZoomFileError):
        aero.parse_zoom_ld(bad)


def test_the_manuals_own_example_file_is_detected_as_placeholder_data():
    """The ZOOM manual's example file repeats one number sequence across 'alphamd' (an angle), 'cl0' and
    'clalpha' (lift coefficients) and 'k' (a drag-due-to-lift factor). Those cannot all be the same numbers, so
    the reader must say so rather than let it be flown."""
    example = """EXAMPLE LIFT, DRAG AERODYNAMIC FILE
///

len units      ft
alt units     nmi
ang units     deg

     sref    45.6

   mach #      0.    0.05    0.12    0.18    0.56    0.82    1.03   1.253
 altitude      0.    5.45
  alphamd   0.205   0.213   0.244   0.296    0.32   0.415   0.733   1.128
            0.194   0.205   0.235   0.282   0.285   0.392   0.702   1.054
 cdmin-on   0.163   0.194   0.246    0.27   0.365   0.683   1.078   1.002
            0.145   0.158   0.184   0.165   0.207   0.607   0.971   0.905
cdmin-off   0.213   0.244   0.296    0.32   0.415   0.733   1.128   1.052
            0.195   0.208   0.234   0.215   0.257   0.657   1.021   0.955

   mach #      0.    0.04    0.16    0.21    0.43    1.75    2.89    7.56
      cl0   0.205   0.213   0.244   0.296    0.32   0.415   0.733   1.128
  clalpha   0.205   0.213   0.244   0.296    0.32   0.415   0.733   1.128
"""
    p = aero.parse_zoom_ld(example)
    assert p["placeholder_warning"], "the format example must be flagged, not silently accepted"
    assert "EXAMPLE" in p["placeholder_warning"] or "example" in p["placeholder_warning"]


# ------------------------------------------------------------------ the integration identity
def test_the_four_losses_and_the_final_speed_reconstruct_the_ideal_delta_v():
    """Book Eq. 6:58. This is the identity that makes the loss budget trustworthy: it is not four separate
    estimates, it is one integration decomposed, and it must close to integration accuracy."""
    _, t = flown()
    assert t.converged
    assert t.closure_residual_mps == pytest.approx(0.0, abs=1e-6)
    assert t.ideal_dv_mps == pytest.approx(t.burnout_v_mps + t.total_loss_mps, rel=1e-9)


def test_every_loss_is_non_negative_and_the_biggest_is_gravity():
    _, t = flown()
    for name in ("gravity_loss_mps", "drag_loss_mps", "propulsion_loss_mps", "steering_loss_mps"):
        assert getattr(t, name) >= 0.0, name
    assert t.gravity_loss_mps > t.drag_loss_mps
    assert t.gravity_loss_mps > t.propulsion_loss_mps


def test_the_trajectory_looks_like_the_book_says_a_good_one_should():
    """Book p.379: max-q between 50 and 90 s, flight path angle running 90 -> ~0, altitude climbing smoothly."""
    _, t = flown()
    assert 50.0 <= t.max_q_t_s <= 90.0, t.max_q_t_s
    assert t.gamma_deg[0] == pytest.approx(90.0, abs=1e-6)
    assert abs(t.burnout_gamma_deg) < 5.0
    assert t.max_q_Pa > 10e3
    assert 0.8 < t.max_q_mach < 3.0
    assert t.burnout_h_m > 100e3


def test_the_altitude_and_speed_histories_are_monotone_where_they_should_be():
    _, t = flown()
    assert all(b >= a - 1.0 for a, b in zip(t.h_m, t.h_m[1:])), "the vehicle should not descend during ascent"
    assert t.v_mps[0] == 0.0 and t.burnout_v_mps > 5000.0


def test_a_finer_time_step_does_not_move_the_answer():
    """If the losses depended on the step the whole exercise would be worthless."""
    r, _ = flown()
    a = tj.fly_design(r, dt=0.5, kick_deg=0.2382)
    b = tj.fly_design(r, dt=0.1, kick_deg=0.2382)
    assert a.burnout_v_mps == pytest.approx(b.burnout_v_mps, rel=2e-3)
    assert a.gravity_loss_mps == pytest.approx(b.gravity_loss_mps, rel=3e-3)
    assert a.drag_loss_mps == pytest.approx(b.drag_loss_mps, rel=2e-2)


# ------------------------------------------------------------------ guidance and shooting
def test_a_pure_gravity_turn_has_no_steering_loss():
    """The point of a gravity turn: thrust along the velocity vector, so the Eq. 6:58 steering integrand is
    identically zero."""
    r, _ = flown()
    veh = tj.ascent_vehicle_from_result(r)
    out = tj.integrate(veh, tj.Guidance(kick_deg=0.2382, terminal_mode="none"), dt=0.3)
    assert out.steering_loss_mps == 0.0
    assert out.max_alpha_deg == 0.0


def test_terminal_guidance_buys_altitude_and_charges_a_steering_loss():
    r, _ = flown()
    veh = tj.ascent_vehicle_from_result(r)
    free = tj.integrate(veh, tj.Guidance(kick_deg=0.2382, terminal_mode="none"), dt=0.3)
    guided = tj.integrate(veh, tj.Guidance(kick_deg=0.2382), dt=0.3)
    assert guided.steering_loss_mps > 0.0
    assert guided.burnout_h_m > free.burnout_h_m
    assert guided.burnout_v_mps < free.burnout_v_mps      # the manoeuvre is not free


def test_a_bigger_kick_gives_a_lower_flatter_trajectory():
    """The monotone behaviour the book's shooting method relies on (Fig. 6.18)."""
    r, _ = flown()
    veh = tj.ascent_vehicle_from_result(r)
    hs = [tj.integrate(veh, tj.Guidance(kick_deg=k), dt=0.4).burnout_h_m for k in (0.15, 0.25, 0.35)]
    assert hs[0] > hs[1] > hs[2], hs


def test_shooting_hits_the_target_altitude():
    r, t = flown()
    assert abs(t.burnout_h_m - r.spec.mission["perigee_altitude_m"]) < 1e4


def test_an_unreachable_altitude_is_reported_not_faked():
    r, _ = flown()
    veh = tj.ascent_vehicle_from_result(r)
    out = tj.shoot_for_altitude(veh, 20_000e3, dt=0.5)       # 20,000 km on a two-stage kerolox: no
    assert not out.converged
    assert "altitude" in out.status


# ------------------------------------------------------------------ against real vehicles
def test_titan_ii_losses_land_inside_the_books_own_ranges():
    """The strongest external check available: book Table 3.4 (p.180) gives gravity 1,150-1,534 m/s, drag
    40-156 m/s for real launches, and p.379 says max-q should fall between 50 and 90 s."""
    r = size_vehicle(load_design(os.path.join(ROOT, "validation", "titan2.yaml"), ASSUMP))
    t = tj.fly_design(r, dt=0.3)
    assert t.converged, t.status
    assert 1100.0 < t.gravity_loss_mps < 1600.0, t.gravity_loss_mps
    assert 30.0 < t.drag_loss_mps < 200.0, t.drag_loss_mps
    assert 50.0 <= t.max_q_t_s <= 90.0, t.max_q_t_s


def test_a_vehicle_whose_upper_stage_cannot_hold_a_flight_path_is_diagnosed():
    """Delta II's second stage ignites at T/W ~ 0.25. A gravity turn cannot fly that, and the tool has to say
    which of the two is at fault - the guidance model, not the vehicle."""
    r = size_vehicle(load_design(os.path.join(ROOT, "validation", "delta2_7920.yaml"), ASSUMP))
    t = tj.fly_design(r, dt=0.5)
    assert not t.converged
    assert any("T/W" in n for n in t.notes), t.notes


def test_a_restarting_upper_stage_can_be_stopped_at_insertion():
    """Saturn V's third stage burns twice; flying both back to back is not an ascent. `last_ascent_stage`
    ends the integration at parking-orbit insertion."""
    r = size_vehicle(load_design(os.path.join(ROOT, "validation", "saturn5.yaml"), ASSUMP))
    veh = tj.ascent_vehicle_from_result(r, last_ascent_stage=2)
    assert all("stage 3" not in b.name for b in veh.burns)
    t = tj.fly_design(r, dt=0.4, last_ascent_stage=2)
    assert t.converged, t.status
    assert 1200.0 < t.gravity_loss_mps < 2400.0


def test_the_vehicle_built_from_a_result_conserves_its_mass_budget():
    r, _ = flown()
    veh = tj.ascent_vehicle_from_result(r)
    m = veh.m0_kg - veh.fairing_kg
    for b in veh.burns:
        m -= b.startup_kg + b.mdot_kgs * b.duration_s + b.jettison_kg
    expect = r.payload_mass_kg + r.paf_mass_kg
    assert m == pytest.approx(expect, rel=1e-6), (m, expect)
