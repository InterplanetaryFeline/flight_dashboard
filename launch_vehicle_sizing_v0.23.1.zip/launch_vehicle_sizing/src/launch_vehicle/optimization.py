"""Optional optimisation mode - separate from the converged sizing solution.

Minimises gross liftoff mass over the stage delta-v allocation (the free design variables of a serial stack at
fixed stage count, propellants, diameters and structural model). Each objective evaluation is a full converged
sizing. The result is a LOCAL optimum inside the stated bounds; global optimality is NOT claimed.
Stage count / propellant combinations are compared by evaluating explicitly supplied configurations
(compare_designs), never by implicit search.
"""
from __future__ import annotations
import math
import copy
import numpy as np
from scipy.optimize import minimize_scalar, minimize
from .convergence import size_vehicle, SizingError
from .validation import InputError

PENALTY = 1e12


def _glom(spec, fractions):
    s = copy.deepcopy(spec)
    s.dv_mode, s.dv_fractions, s.dv_fixed = "fractions", list(fractions), None
    try:
        r = size_vehicle(s, keep_history=False)
        if not r.converged:
            return PENALTY
        # constraint violations are penalised in graded form so the search keeps a usable ordering by GLOM
        return r.glom_kg + (1e9 if any(i.level == "ERROR" for i in r.issues) else 0.0)
    except (SizingError, InputError):
        return PENALTY


def optimize_dv_split(spec, lo: float = 0.05, hi: float = 0.95) -> dict:
    N = len(spec.stages)
    if N == 1:
        raise InputError("nothing to optimise for a single stage")
    if N == 2:
        res = minimize_scalar(lambda x: _glom(spec, [x, 1 - x]), bounds=(lo, hi), method="bounded", options=dict(xatol=1e-4))
        fr = [float(res.x), 1.0 - float(res.x)]
        nfev = res.nfev
    else:
        def f(v):
            e = np.exp(np.clip(v, -6, 6))
            return _glom(spec, list(np.append(e, 1.0) / (e.sum() + 1.0)))
        best = minimize(f, np.zeros(N - 1), method="Nelder-Mead", options=dict(xatol=1e-4, fatol=1e-3, maxiter=300))
        e = np.exp(np.clip(best.x, -6, 6))
        fr = [float(x) for x in np.append(e, 1.0) / (e.sum() + 1.0)]
        nfev = best.nfev
    base = _glom(spec, spec.dv_fractions) if spec.dv_mode == "fractions" else float("nan")
    opt = _glom(spec, fr)
    return dict(fractions=fr, glom_kg=opt, baseline_glom_kg=base, evaluations=nfev, success=opt < 1e9,
                note="Local optimum of GLOM over stage dv allocation within bounds; structural model and stage count fixed. Not a global optimum.")


def compare_designs(specs: dict) -> list:
    rows = []
    for name, sp in specs.items():
        try:
            r = size_vehicle(sp, keep_history=False)
            rows.append(dict(name=name, glom_kg=r.glom_kg, converged=r.converged, feasible=not any(i.level == "ERROR" for i in r.issues),
                             length_m=r.geometry.total_length, dv_req=r.dv_required_mps))
        except (SizingError, InputError) as ex:
            rows.append(dict(name=name, glom_kg=float("nan"), converged=False, feasible=False, length_m=float("nan"), dv_req=float("nan"), note=str(ex)))
    return rows


# --------------------------------------------------------------------------- analytical optimum (book Sec. 5.8)
def analytical_optimum(c_eff_mps: list, sigma: list, dv_total_mps: float, tol: float = 1e-10) -> dict:
    """Book Eqs. 5:30-5:33 (pp.287-288): the Lagrange-multiplier optimum of the step mass ratios.

    The book writes mu_i = (1 + L c_i)/(L c_i sigma_i) with a Lagrange multiplier L that comes out negative;
    substituting lam = -L gives the equivalent positive form used here,

        mu_i = (lam c_i - 1) / (lam c_i sigma_i),        v_f = sum_i c_i ln mu_i,

    which is solved for lam by bisection. mu_i > 1 requires lam > 1/(c_i (1 - sigma_i)), so the search starts just
    above the largest of those bounds; mu_i < 1/sigma_i holds automatically, i.e. the optimum is always feasible.

    This is the *unrestricted* staging optimum: it assumes each step's structural ratio sigma_i and effective
    exhaust speed c_i are fixed and independent of its size. In this tool they are not - sigma comes out of a
    mass build-up that depends on the stage's own size - so the analytical answer is a cross-check and a first
    guess, not a replacement for the numerical search (see optimize_dv_split).
    """
    n = len(c_eff_mps)
    if n != len(sigma) or n < 2:
        raise InputError("analytical staging optimum needs at least two steps with matching c and sigma")
    if any(s <= 0 or s >= 1 for s in sigma):
        raise InputError("structural ratios must lie strictly between 0 and 1")
    lam_lo = max(1.0 / (c * (1.0 - s)) for c, s in zip(c_eff_mps, sigma)) * (1.0 + 1e-12)

    def dv_of(lam):
        tot = 0.0
        for c, s in zip(c_eff_mps, sigma):
            mu = (lam * c - 1.0) / (lam * c * s)
            if mu <= 1.0:
                return -1.0
            tot += c * math.log(mu)
        return tot

    lam_hi = lam_lo * 2.0
    for _ in range(200):
        if dv_of(lam_hi) > dv_total_mps:
            break
        lam_hi *= 2.0
    else:
        raise InputError("no Lagrange multiplier reaches the required delta-v with these structural ratios")
    lo, hi = lam_lo, lam_hi
    for _ in range(300):
        mid = 0.5 * (lo + hi)
        if dv_of(mid) < dv_total_mps:
            lo = mid
        else:
            hi = mid
        if hi - lo < tol * max(1.0, hi):
            break
    lam = 0.5 * (lo + hi)
    mus = [(lam * c - 1.0) / (lam * c * s) for c, s in zip(c_eff_mps, sigma)]
    dvs = [c * math.log(mu) for c, mu in zip(c_eff_mps, mus)]
    tot = sum(dvs)
    return dict(lagrange_lambda=lam, lagrange_L=-lam, mass_ratios=mus, dv_mps=dvs,
                fractions=[d / tot for d in dvs], dv_total_mps=tot,
                note="Book Eqs. 5:32-5:33 (pp.288). Valid for fixed sigma_i and c_i; sigma here is the converged "
                     "structural factor of each stage, so the result is a cross-check on the numerical optimum.")


def analytical_optimum_from_result(res) -> dict:
    """Apply the book's analytical optimum to a converged design, using its own c_eff and structural factors."""
    from .units import G0
    c = [G0 * s.isp_eff_s for s in res.stages]
    sig = [s.structural_factor_s for s in res.stages]
    out = analytical_optimum(c, sig, res.dv_required_mps)
    out["c_eff_mps"] = c
    out["sigma"] = sig
    return out


def equal_isp_optimum(c_eff_mps: float, sigma: list, dv_total_mps: float) -> dict:
    """Book Eqs. 5:36-5:39: the closed form when every step has the same exhaust speed.

    mu_i = (1/sigma_i) exp[-(1/N)(v_f/c + sum_j ln sigma_j)] ... rearranged from the printed form; with equal
    sigma it reduces to the familiar 'each step provides v_f/N' (restricted staging, p.289).
    """
    n = len(sigma)
    k = math.exp((dv_total_mps / c_eff_mps + sum(math.log(s) for s in sigma)) / n)
    mus = [k / s for s in sigma]
    dvs = [c_eff_mps * math.log(mu) for mu in mus]
    tot = sum(dvs)
    return dict(mass_ratios=mus, dv_mps=dvs, fractions=[d / tot for d in dvs], dv_total_mps=tot,
                note="Book Eqs. 5:37-5:39 (p.289); equal exhaust speed for every step")


def glom_for_fractions(spec, fractions) -> float | None:
    """GLOM of a design whose delta-v is split in the given proportions, or None when that split is infeasible.

    Used to price the analytical optimum inside this tool's own model: the closed form assumes fixed structural
    ratios, so its split has to be re-sized here before its mass can be compared with anything.
    """
    g = _glom(spec, list(fractions))
    return None if g >= PENALTY else g


def restricted_staging_speed_ratio(n_steps: int, payload_ratio: float, sigma: float) -> float:
    """Book Eq. 5:40 (p.289): normalised burnout speed of a vehicle of N *similar* steps (restricted staging).

        v_f / v_e = N ln[ 1 / (pi^(1/N) (1 - sigma) + sigma) ],   and  (1 - sigma) ln(1/pi)  as N -> infinity.

    This is the curve behind the book's Fig. 5.11 and the honest answer to "is another step worth it": the gain
    per added step collapses after three or four. `n_steps=None` returns the infinite-step limit.
    """
    if payload_ratio <= 0 or payload_ratio >= 1:
        raise InputError("payload ratio must lie strictly between 0 and 1")
    if sigma <= 0 or sigma >= 1:
        raise InputError("structural ratio must lie strictly between 0 and 1")
    if n_steps is None:
        return (1.0 - sigma) * math.log(1.0 / payload_ratio)
    if n_steps < 1:
        raise InputError("a vehicle has at least one step")
    return n_steps * math.log(1.0 / (payload_ratio ** (1.0 / n_steps) * (1.0 - sigma) + sigma))


def staging_sweep(spec, n: int = 25, lo: float = 0.15, hi: float = 0.9) -> list:
    """GLOM against the share of delta-v given to stage 1 (two-stage vehicles only) - the curve behind the
    optimum, so a reader can see how flat or sharp it is."""
    if len(spec.stages) != 2:
        return []
    out = []
    for k in range(n):
        f1 = lo + (hi - lo) * k / (n - 1)
        g = _glom(spec, [f1, 1.0 - f1])
        if g < PENALTY:
            out.append(dict(f1=f1, glom_kg=g))
    return out
