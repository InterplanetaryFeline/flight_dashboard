"""Preliminary multistage launch vehicle sizing tool (conceptual-design fidelity)."""
__version__ = "0.23.1"
