# Validation data tables

Generated from `outputs/validation/validation_results.json`. **No parameter was tuned to match a vehicle.** Unsourced engine values are tagged `assumed` in `validation/*.yaml`.

## 1. Real vehicles (payload and orbit as published)

| Vehicle | Published GLOM [t] | As-published split | Optimised split | Lean margins (diag.) | Published casing k (diag.) | Length pred./pub. [m] |
|---|---|---|---|---|---|---|
| Rocket Lab Electron (LOX/RP-1, composite) | 13.0 | 16.8 (+29%) | 16.4 (+26%) | 13.6 (+5%) | n/a | 20.8 / 18.0 |
| SpaceX Falcon 9 Block 5 (expendable, LOX/RP-1) | 549.1 | 636.3 (+16%) | 627.1 (+14%) | 544.3 (-1%) | n/a | 81.5 / 70.0 |
| Titan II GLV (N2O4/Aerozine-50) | 154.0 | 178.6 (+16%) | 178.3 (+16%) | 148.1 (-4%) | n/a | 39.4 / 33.2 |
| Saturn V (RP-1/LOX, LH2/LOX, LH2/LOX) to TLI | 2,894.0 | 2,825.7 (-2%) | 2,651.5 (-8%) | 2,253.1 (-22%) | n/a | 130.0 / 110.6 |
| LandSpace Zhuque-2 (LOX/CH4) | 219.0 | 150.1 (-31%) | 149.5 (-32%) | 126.7 (-42%) | n/a | 39.9 / 49.5 |
| Pegasus XL (3 solid stages, air-launched) | 23.1 | 36.9 (+60%) | 33.6 (+45%) | 30.4 (+32%) | 32.3 (+40%) | 25.7 / 17.6 |
| Vega (P80 + Zefiro 23 + Zefiro 9 + AVUM) | 137.0 | 304.2 (+122%) | 171.0 (+25%) | 151.8 (+11%) | 144.3 (+5%) | 60.0 / 30.0 |
| Epsilon (3 solid stages) | 95.4 | 151.1 (+58%) | 135.5 (+42%) | 121.4 (+27%) | n/a | 38.1 / 26.0 |
| Scout G-1 (4 solid stages) | 21.7 | 54.7 (+152%) | 35.2 (+62%) | 30.7 (+41%) | n/a | 42.5 / 22.9 |
| Firefly Alpha (LOX/RP-1, composite) | 54.0 | 58.8 (+9%) | 57.3 (+6%) | 44.1 (-18%) | n/a | 33.3 / 29.0 |
| Delta II 7920 (9 x GEM-40, 6 ground-lit + 3 air-lit) | 231.9 | 297.4 (+28%) | 231.0 (-0%) | 210.2 (-9%) | n/a | 56.3 / 38.9 |
| Atlas V 551 (5 x AJ-60A + CCB + Centaur III) | 587.0 | 538.6 (-8%) | 475.5 (-19%) | not feasible | n/a | 78.4 / 58.3 |
| Ariane 5 ECA (2 x EAP + EPC + ESC-A) | 780.0 | 855.4 (+10%) | 802.8 (+3%) | 757.1 (-3%) | n/a | 80.6 / 52.0 |
| H-IIA 202 (2 x SRB-A + LE-7A core + LE-5B) | 285.0 | 302.2 (+6%) | 284.3 (-0%) | 269.9 (-5%) | n/a | 68.4 / 53.0 |
| Soyuz-2.1b (4 tapered strap-ons + Blok A + Blok I) | 312.0 | 361.0 (+16%) | 279.3 (-10%) | not feasible | n/a | 45.4 / 46.1 |
| Delta IV Heavy (3 x Common Booster Core + DCSS) | 733.0 | 735.8 (+0%) | 710.8 (-3%) | not feasible | n/a | 77.0 / 70.7 |

## 2. Delta-v of the *published* stage masses vs the requirement the tool computes

| Vehicle | Ideal dv from published masses [m/s] | Required (loss model) [m/s] | Margin |
|---|---|---|---|
| Rocket Lab Electron (LOX/RP-1, composite) | 9,136 | 9,551 | -4.3 % |
| SpaceX Falcon 9 Block 5 (expendable, LOX/RP-1) | 9,221 | 9,097 | +1.4 % |
| Titan II GLV (N2O4/Aerozine-50) | 9,201 | 8,988 | +2.4 % |
| Saturn V (RP-1/LOX, LH2/LOX, LH2/LOX) to TLI | 12,987 | 12,359 | +5.1 % |
| Pegasus XL (3 solid stages, air-launched) | 7,976 | 8,461 | -5.7 % |
| Vega (P80 + Zefiro 23 + Zefiro 9 + AVUM) | 9,876 | 10,264 | -3.8 % |
| Scout G-1 (4 solid stages) | 9,087 | 9,738 | -6.7 % |

## 3. Structural factors: predicted vs published

| Vehicle | Stage | Type | s predicted | s published | ratio |
|---|---|---|---|---|---|
| Rocket Lab Electron | 1 | liquid | 0.0819 | 0.0931 | 0.88 |
| Rocket Lab Electron | 2 | liquid | 0.0831 | 0.1087 | 0.76 |
| SpaceX Falcon 9 Block 5 | 1 | liquid | 0.0611 | 0.0608 | 1.01 |
| SpaceX Falcon 9 Block 5 | 2 | liquid | 0.0508 | 0.0404 | 1.26 |
| Titan II GLV | 1 | liquid | 0.0656 | 0.0538 | 1.22 |
| Titan II GLV | 2 | liquid | 0.0827 | 0.0767 | 1.08 |
| Saturn V | 1 | liquid | 0.0728 | 0.0585 | 1.25 |
| Saturn V | 2 | liquid | 0.0792 | 0.0665 | 1.19 |
| Saturn V | 3 | liquid | 0.0939 | 0.0988 | 0.95 |
| Pegasus XL | 1 | solid | 0.1214 | 0.0836 | 1.45 |
| Pegasus XL | 2 | solid | 0.1311 | 0.0958 | 1.37 |
| Pegasus XL | 3 | solid | 0.1720 | 0.1406 | 1.22 |
| Vega | 1 | solid | 0.1178 | 0.0766 | 1.54 |
| Vega | 2 | solid | 0.1229 | 0.0751 | 1.64 |
| Vega | 3 | solid | 0.1264 | 0.0802 | 1.58 |
| Vega | 4 | liquid | 0.1396 | 0.1924 | 0.73 |
| Scout G-1 | 1 | solid | 0.1375 | 0.1314 | 1.05 |
| Scout G-1 | 2 | solid | 0.1607 | 0.2202 | 0.73 |
| Scout G-1 | 3 | solid | 0.1356 | 0.2050 | 0.66 |
| Scout G-1 | 4 | solid | 0.2144 | 0.1602 | 1.34 |
| Delta II 7920 | 1 | liquid | 0.0727 | 0.0558 | 1.30 |
| Delta II 7920 | 2 | liquid | 0.0601 | 0.1366 | 0.44 |
| Atlas V 551 | 1 | liquid | 0.0925 | 0.0690 | 1.34 |
| Atlas V 551 | 2 | liquid | 0.0879 | 0.0972 | 0.90 |
| Ariane 5 ECA | 1 | liquid | 0.0895 | 0.0796 | 1.12 |
| Ariane 5 ECA | 2 | liquid | 0.0946 | 0.2335 | 0.41 |
| H-IIA 202 | 1 | liquid | 0.1127 | 0.0982 | 1.15 |
| H-IIA 202 | 2 | liquid | 0.1020 | 0.1531 | 0.67 |
| Soyuz-2.1b | 1 | liquid | 0.1041 | 0.0677 | 1.54 |
| Soyuz-2.1b | 2 | liquid | 0.0714 | 0.0848 | 0.84 |
| Delta IV Heavy | 1 | liquid | 0.1059 | 0.1178 | 0.90 |
| Delta IV Heavy | 2 | liquid | 0.0972 | 0.1136 | 0.86 |

## 4. Propellant types on one mission (10 t to 400 km LEO, 28.5 deg, GLOM-minimising dv split)

| Combination | GLOM [t] | Dry [t] | Payload fraction | Length [m] | dv [m/s] |
|---|---|---|---|---|---|
| LOX/RP-1 + LOX/RP-1 | 353.3 | 15.2 | 2.83 % | 51.8 | 9,429 |
| LOX/LCH4 + LOX/LCH4 | 299.9 | 14.5 | 3.33 % | 53.4 | 9,454 |
| LOX/LH2 + LOX/LH2 | 180.6 | 14.0 | 5.54 % | 53.8 | 9,546 |
| LOX/RP-1 + LOX/LH2 | 211.4 | 13.7 | 4.73 % | 53.1 | 9,521 |
| N2O4/A-50 + N2O4/A-50 | 478.8 | 18.3 | 2.09 % | 55.7 | 9,388 |