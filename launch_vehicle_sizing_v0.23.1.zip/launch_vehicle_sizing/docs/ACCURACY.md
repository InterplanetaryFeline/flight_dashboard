# How close is this tool to real launch vehicles, and why isn't it closer?

Generated from `outputs/validation/validation_results.json` and `outputs/validation/error_attribution.json`
(`tools/run_validation.py`, then `tools/attribute_error.py`). **No parameter has been tuned to match a
vehicle.** Every input in `validation/*.yaml` carries its own source in its `s:` field.

This document answers two questions that the validation report answers only in pieces: *how far off is each
vehicle*, and *which part of the model put it there*. If you only read one thing, read §1 and §5.

---

## 1. The short version

Eighteen real vehicles, sized from payload and orbit with the delta-v split re-optimised:

| | N | median \|GLOM error\| | mean |
|---|---|---|---|
| **All-liquid vehicles** | 12 | **9.4 %** | 11.5 % |
| **Vehicles with serial solid stages** | 6 | **33.4 %** | 32.6 % |

The tool is a usable conceptual-design estimator for liquid vehicles and a **systematically optimistic-sized,
high-variance** one for solid vehicles. The gap is not one mistake. It is two model errors that happen to
land on the same population, multiplied by a sensitivity that is three times higher there.

**Use it for liquid architectures with confidence at the ±10 % level. For solid stages, name a real motor
or expect to be 20–60 % heavy, and never let a liquid-versus-solid trade turn on a margin smaller than
30 %** unless you have replaced the solid mass method — see §6.

---

## 2. Every vehicle, measured

`GLOM error` is the optimised-split run against the published lift-off mass. `dv gap` is what the tool asks
of the mission minus what that vehicle's own published masses and Isp actually deliver — positive means the
tool thinks the mission is harder than the real rocket found it. `mass bias` is the tool's predicted stage
inert against the published stage inert **at the published propellant load**, averaged over the stages whose
masses are published; feeding the real propellant removes the delta-v budget, the Isp and the staging split
from that comparison, so what is left is the mass model alone. `dGLOM/dInert` is measured, not assumed: every
stage's inert margin is raised 10 % and the resulting GLOM change is divided by 0.10.

| vehicle | solid | GLOM error | dv gap [m/s] | mass bias | dGLOM/dInert |
|---|---|---|---|---|---|
| H-IIA 202 | – | −0.2 % | | | 0.24 |
| Delta II 7920 | – | −0.4 % | | | 0.48 |
| Ariane 5 ECA | – | +2.9 % | | | 0.32 |
| Delta IV Heavy | – | −3.0 % | | | 0.11 |
| **M-V** | **YES** | **+3.9 %** | **−1,058** | **+34.2 %** | 1.28 |
| Firefly Alpha | – | +6.1 % | | | 0.79 |
| Saturn V | – | −8.4 % | −628 | | 0.40 |
| Soyuz-2.1b | – | −10.5 % | | | 0.43 |
| Falcon 9 | – | +14.2 % | −123 | | 0.23 |
| Titan II GLV | – | +15.8 % | −213 | | 0.53 |
| **Vega C** | **YES** | **+17.3 %** | +174 | **+62.0 %** | 1.39 |
| Atlas V 551 | – | −19.0 % | | | 0.21 |
| **Vega** | **YES** | **+24.8 %** | +389 | **+65.2 %** | 1.52 |
| Electron | – | +25.8 % | +415 | | 0.53 |
| Zhuque-2 | – | −31.7 % | | | 0.59 |
| **Epsilon** | **YES** | **+42.0 %** | | | 1.30 |
| **Pegasus XL** | **YES** | **+45.4 %** | +485 | **+42.3 %** | 1.16 |
| **Scout G-1** | **YES** | **+62.3 %** | +651 | **+12.4 %** | 1.87 |

Blank cells mean the published data needed for that measurement does not exist for that vehicle — per-stage
inert masses for the mass bias, per-stage masses and Isp for the dv gap. Nothing has been estimated to fill
a blank.

**The sensitivity column is the one most worth staring at.** Liquid vehicles sit at 0.11–0.79: a 10 % inert
error moves GLOM by 1–8 %. Solid vehicles sit at **1.16–1.87**: the same 10 % error moves GLOM by 12–19 %.
A solid stage carries a bigger inert fraction and a worse mass ratio, so the fixed point amplifies rather
than damps. **The solid mass model is worse AND it matters more.** That is the whole story in one line.

---

## 3. Why each solid vehicle lands where it does

These six are the interesting cases, and no two fail the same way.

**M-V, +3.9 % — the one the book gets right, for the wrong reason.** Its dv gap is **−1,058 m/s**: the real
vehicle carries over a kilometre per second more capability than the tool asks of the mission, because the
quoted 1,800 kg payload and the published stage masses are not from the same flight. That surplus almost
exactly cancels a **+34.2 %** mass bias. Two large errors in opposite directions. M-V is also the only solid
vehicle here whose first stage is **heavier** than the book's constant — inert/propellant 0.153 against
k = 0.1154 — which is a useful corrective to the idea that the book is uniformly conservative about solids.
It is not conservative; it is uncalibrated, and which way it errs depends on the vehicle.

**Vega C, +17.3 % and Vega, +24.8 % — the clean cases.** Modest dv gaps (+174, +389 m/s) and the largest mass
biases in the set (**+62.0 %, +65.2 %**). These are modern filament-wound motors, which are much lighter than
the book's coefficient, and nothing else is going on. Substituting each stage's own published
inert/propellant ratio brings Vega to **+5 %** and Vega C to **+3.4 %**, which is the proof that the sizing
machinery around the coefficient is sound.

**Epsilon, +42.0 %.** No published per-stage inert masses, so no mass bias can be measured. Its sensitivity
is 1.30 and its stages are the same filament-wound class as Vega's, so the same cause is the likely one, but
this is inference rather than measurement and is labelled as such.

**Pegasus XL, +45.4 %.** A +485 m/s dv gap on top of a +42.3 % mass bias, and both are explicable. The dv gap
is an air-launch loss regression that was never fitted to air launch — the published errata replaces the
40 m/s drag figure with the **322 m/s measured on the first flight**, and the tool now carries that. The
mass bias is the usual filament-wound story.

**Scout G-1, +62.3 % — the worst, and the one with the *smallest* mass bias.** Only **+12.4 %**, yet the
largest GLOM error in the set. Two reasons. Its dv gap is the largest (**+651 m/s**, against a loss
regression whose own stated RMS error is 260 m/s), and its sensitivity is the highest (**1.87**). A
four-stage solid sized to the edge of its capability multiplies everything. The low mass bias is itself
two errors cancelling: the book over-predicts Scout's motors by ~50 % while the build-up under-charges its
stage equipment by a similar amount — see §4.3.

---

## 4. The sources of discrepancy, each with its measured size

Ordered by how much damage each does.

### 4.1 The solid casing coefficient is a constant where reality has a strong size trend

**Measured against 55 STAR-family motors** whose loaded and burnout masses are published together, so the
difference is motor inert with no stage equipment in it (`solid_inert.MOTOR_DATASET`):

| propellant | motors | measured inert/propellant | book k = 0.1154 |
|---|---|---|---|
| under 100 kg | 8 | 0.184 | **−36 %** |
| 100 – 500 kg | 20 | 0.092 | **+26 %** |
| 500 – 1,500 kg | 19 | 0.080 | **+44 %** |
| over 1,500 kg | 8 | 0.076 | **+51 %** |

Motor inert fraction falls from ~0.18 at 30 kg of propellant toward a floor near 0.060, so a single constant
crosses the real curve near 150–200 kg and is wrong in opposite directions either side. The fitted
alternative, `star_motor` (`f = 0.0602 + 0.0051 (m_p/4536)^(-2/3)`, MAPE 14 %), is scoped to upper-stage
class: tested against real launch-vehicle *stages* it runs 31 % light, because apogee-kick motors carry no
TVC and no flight structure and are genuinely a different product.

**Effect on a vehicle:** the dominant term for Vega, Vega C and Pegasus. Worth 29 % of lift-off mass on a
three-stage solid carrying 150 kg to 500 km polar.

### 4.2 The ascent-loss regression was not fitted to small multi-stage solids

Book Eq. 3:37–3:38, stated RMS error ~260 m/s. Measured dv gaps: Scout **+651**, Pegasus **+485**,
Electron **+415**, Vega **+389**. All four are small vehicles; the large ones sit at −123 to −628 m/s, i.e.
the regression is generous to them.

On Scout this accounts for roughly **35 of its 62 percentage points** — more than the mass model does. A
four-stage solid that is over in 176 s of burn is not the kind of ascent the regression was fitted to.
`losses.model: user` or the 3-DoF trajectory are the ways out.

### 4.3 Stage equipment that does not scale

The build-up's skirts, avionics, wiring and separation hardware are assumed values that do not change with
stage size. On a large stage they are a rounding error. On a small one they are most of the mass, and the
assumption is badly short:

* Scout stage 3: the real stage carries **237 kg** of equipment on a 98 kg motor. The tool charges **50 kg**.
* Scout stage 4: predicted 73 kg against 41 kg published, **but 36 kg of that is a forward adapter cone**
  that LTV books separately as the heatshield. Like-for-like the error is **−19 %**, not +77 %.

This is the half of the solid problem that is still unmodelled (roadmap **R33**). It has been invisible
because it cancels against §4.1 — and that cancellation is accidental and size-dependent, so **fixing §4.1
alone makes small notional upper stages come out light**. Naming a real motor fixes both at once, which is
why §6 recommends it.

### 4.4 Bookkeeping: the sources do not agree on what a "stage" contains

Three separate instances found:

* **Scout stage 4** — the adapter/heatshield above, worth 96 percentage points of apparent error.
* **Vega C** — stage inert masses differ by **20–54 %** between Wikipedia (11,200 / 3,230 / 929 kg) and
  Zandbergen (13,393 / 4,238 / 1,433 kg) *for the same three motors*. Almost certainly motor-level against
  stage-level, and neither source says which. The case cites the figures it uses.
* **Motor versus stage generally** — the book's k is a motor coefficient; most published "inert masses" are
  stage-level. Comparing them directly is what made solid results unreadable before `MOTOR_DATASET` existed.

When a published figure and a predicted one disagree by more than about 30 %, **check what each contains
before believing the model is wrong**.

### 4.5 The delta-v split matters more than almost anything else

Vega sized with its as-published split is **304 t**; re-optimised it is **171 t**, against 137 t published.
The same vehicle, the same mass model, a 78 % difference. Scout: 54.7 t against 35.2 t. A fixed split that
is far from optimal inflates mass enormously, and for a marginal vehicle the inflation is violent.

The optimiser also **does not know about casing geometry**: on M-V it starves the 2.2 m third stage below
what that diameter can physically hold, and the run falls back to the as-published split and says so.

### 4.6 Smaller contributors, for completeness

* **Engine mass MER** is biased low by about 22 % against 16 real engines; `mer_calibrated` applies the
  measured 1.221 factor.
* **The avionics MER is a step function** — 75 kg below a 1 t payload, 350 kg above it. A small launcher
  just over the threshold is charged 350 kg on an upper stage weighing a few hundred kilograms.
  `avionics_mass_override_kg` exists for this.
* **Solid thrust is modelled as the burn average**, where a real grain is front-loaded. Lift-off T/W comes
  out low (1.12 against ~1.8 for Ariane 5). A modelling choice, not an error, but it matters if you
  constrain on lift-off T/W.
* **Liquid strap-ons are one bulk-density envelope** with no intertank, so the modelled Delta IV Common
  Booster Core is 37.3 m against a real 40.8 m (roadmap R27).
* **An oversized design produces oversized hardware, and the tool says so.** Scout G-1 and M-V both raise
  `ENGFIT` on the as-published split: the nozzle is computed from the thrust the *sized* vehicle needs, and
  a nozzle for a 54 t Scout does not fit on a 1.14 m case. The error is a true statement about the design
  the tool produced, not a bad assumption, and it is left in rather than suppressed by lowering an assumed
  expansion ratio - which would hide the oversizing instead of fixing it.
* **Length is predicted worse than mass, everywhere.** The tool runs long — Vega 60 m against 30 m, Scout
  42.5 m against 22.9 m — because stages are sized at a fixed user diameter and the layout adds generous
  skirts and interstages. Treat predicted length as an upper bound.

---

## 5. What this means for a trade study

**The error is not random, so it does not cancel between architectures.** A liquid-versus-solid comparison
run on defaults is biased against the solid option by roughly the amount in §4.1, amplified by the
sensitivity in §2. On the three-stage solid example that is 29 % of lift-off mass — larger than the margin
most such trades turn on.

Three practical consequences:

1. **A trade whose two architectures sit within 30 % of each other is not decidable on defaults.** Replace
   the solid mass method first (§6), then re-run.
2. **Comparisons within one architecture class are far more trustworthy than comparisons across classes.**
   Two liquid variants, or two solid variants, share their biases; a liquid against a solid does not.
3. **The relative ordering of propellant combinations on the same mission is more reliable than any
   absolute mass**, because the delta-v and loss terms are common to all of them.

---

## 6. What to do about it

In order of how much they buy you:

1. **Name a real motor for any solid stage.** `motor.from_database: "Star 37FM"` **with
   `casing_mass_method: mass_fraction`** uses that motor's own published inert/propellant ratio. Eleven STAR
   motors are in the database, 112–4,265 kg of propellant, k from 0.0616 to 0.125. This fixes §4.1 and §4.3
   together, because a real motor's mass is a real motor's mass. Naming a motor and leaving a `book_*`
   method in place now raises a `CASEDB` warning, because the real figure would otherwise be loaded and then
   ignored.
2. **For a notional upper-stage-class motor, use `casing_mass_method: star_motor`.** Not for a booster.
3. **Re-optimise the delta-v split** (§4.5) before reading any absolute mass.
4. **Replace the loss model** for a small multi-stage solid — `losses.model: user` with a measured or
   assumed allowance, or run the 3-DoF trajectory (§4.2).
5. **Override the avionics step** on a small launcher just above the 1 t payload threshold.
6. **Read the warnings.** `CASEDB`, `CASESTAGE`, `CASEMARGIN`, `ENGCAL` and `SITELAT` each mark a place
   where the tool knows the answer is suspect.

---

## 7. What would move the numbers most

From the roadmap, ordered by measured payoff rather than by effort:

| | what | worth |
|---|---|---|
| **R33** | A stage-equipment model that scales with stage size | the other half of the solid error; currently masked by §4.1 |
| **R32** | Flag when a design falls outside the loss regression's fitted population | 35 of Scout's 62 points |
| **R30** | Refuse to extrapolate an affine relation below its fitted floor | prevents a 378 % error that currently just happens |
| **R29** | The avionics step function | the biggest single term on a small launcher |
| **R21** | Close the structure → mass loop | the largest error the tool can see and declines to act on |

---

## 8. Honesty notes

* Six solid vehicles is a small sample, and two of them (M-V and Vega C) were added in v0.21. The medians in
  §1 will move as more are added: they moved from 43.7 % to 33.4 % when the sample went from four to six, and
  that was a change in the sample, not an improvement to the model.
* `mass bias` is measured only where per-stage inert masses are published — four of the six solid vehicles.
* The three attribution columns in §2 **do not sum to the GLOM error**, and are not meant to. A rocket is a
  fixed point; a mass error and a delta-v error interact, and the interaction grows as a vehicle approaches
  the edge of its capability. They are attributions, not a decomposition.
* Published figures disagree with each other (§4.4). Where two sources conflict the case cites the one it
  used, and the disagreement is reported rather than averaged away.
