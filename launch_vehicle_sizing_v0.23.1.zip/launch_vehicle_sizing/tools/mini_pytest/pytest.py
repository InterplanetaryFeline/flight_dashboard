"""Minimal stand-in for the subset of pytest used by this test-suite (approx, raises).
Only used when the real pytest cannot be installed (offline sandbox). With real pytest installed, ignore this."""
import math


class approx:
    def __init__(self, expected, rel=1e-6, abs=1e-12):
        self.expected, self.rel, self.abs = expected, rel, abs

    def __eq__(self, actual):
        tol = max(self.abs, self.rel * math.fabs(self.expected))
        return math.fabs(actual - self.expected) <= tol

    def __repr__(self):
        return f"approx({self.expected}, rel={self.rel}, abs={self.abs})"


class _Raises:
    """Context manager with the same surface the suite uses: `.value` holds the caught exception afterwards."""

    def __init__(self, exc, match=None):
        self.exc, self.match, self.value = exc, match, None

    def __enter__(self):
        return self

    def __exit__(self, et, ev, tb):
        if et is None:
            raise AssertionError(f"DID NOT RAISE {self.exc}")
        if not issubclass(et, self.exc):
            return False
        if self.match and self.match.lower() not in str(ev).lower():
            raise AssertionError(f"exception text {str(ev)!r} does not contain {self.match!r}")
        self.value = ev
        return True


def raises(exc, match=None):
    return _Raises(exc, match)


def fixture(*a, **kw):
    """Not supported: this shim has no fixture machinery. Tests here use plain helper functions instead, so a
    fixture decorator in a test file is a mistake worth failing loudly on rather than silently mis-running."""
    raise NotImplementedError("tools/mini_pytest has no fixture support - use a module-level helper function "
                              "(see tests/test_report.py) so the suite runs with and without real pytest")


class mark:
    @staticmethod
    def skip(*a, **kw):
        def deco(fn):
            fn.__mini_skip__ = True
            return fn
        return deco
