"""Tiny test runner: python tools/run_tests.py  (discovers tests/test_*.py, runs test_* functions).
Prefers real pytest when available: if `import pytest` works from site-packages, run `python -m pytest -v` instead."""
import importlib.util, os, sys, time, traceback, glob
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path[:0] = [os.path.join(root, "src"), os.path.join(root, "tests"), os.path.join(root, "tools", "mini_pytest")]
try:
    import pytest as _p
    if not hasattr(_p, "approx") or "mini_pytest" not in getattr(_p, "__file__", ""):
        os.chdir(root); sys.exit(__import__("subprocess").call([sys.executable, "-m", "pytest", "-v", "tests"]))
except ImportError:
    pass
os.chdir(root)
passed = failed = 0
fails = []
t0 = time.time()
for path in sorted(glob.glob(os.path.join(root, "tests", "test_*.py"))):
    spec = importlib.util.spec_from_file_location(os.path.basename(path)[:-3], path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    for name in sorted(n for n in dir(mod) if n.startswith("test_")):
        fn = getattr(mod, name)
        if not callable(fn): continue
        try:
            fn(); passed += 1; print(f"PASS  {os.path.basename(path)}::{name}")
        except Exception:
            failed += 1; fails.append((path, name)); print(f"FAIL  {os.path.basename(path)}::{name}"); traceback.print_exc()
print(f"\n{passed} passed, {failed} failed in {time.time()-t0:.1f}s  (runner: mini_pytest shim; real pytest not available)")
sys.exit(1 if failed else 0)
