outputs/ — generated artefacts
==============================

Everything in this directory is GENERATED. Nothing here is a source of truth, and nothing here needs to be
kept: delete the lot and one command puts it back.

The release archive ships only one file from here, `engineering_method_register.xlsx` (and its .csv twin),
because the README points at it as the record of all 95 engineering methods with their book page, assumptions,
limits and verification basis, and it should be readable without running anything first. Every other artefact
was left out to keep the archive small.

To regenerate everything:

    PYTHONPATH=src python -m launch_vehicle.main run --out outputs --all-studies --pdf --cad

That writes the design report, the Excel workbook, the schematics, the CSV tables, run_summary.json, the CAD
exports and the method register. The optional PDF step needs Chrome or wkhtmltopdf, and the exact-solid CAD
formats need the optional geometry kernel (see requirements.txt); everything else works with the base install.

The validation set, per-vehicle reports and drawings:

    PYTHONPATH=src python tools/run_validation.py
    PYTHONPATH=src python tools/build_validation_report.py

The GUI writes its own runs into a work directory of its own, not here.
