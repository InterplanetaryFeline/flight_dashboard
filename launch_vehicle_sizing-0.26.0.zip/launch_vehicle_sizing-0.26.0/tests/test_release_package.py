"""The release archive: is it the whole tool, and is it only the tool?

Packaging used to be done by hand, which is how an archive ends up carrying a `__pycache__`, somebody's
half-finished GUI draft and last week's generated report - and how it ends up missing a file nobody noticed
was needed until someone unzipped it on another machine. `tools/make_release.py` answers both questions, and
these tests keep its answers honest: in particular that every path it calls REQUIRED is a path that actually
exists, which is the check that caught a documented file that was never there.
"""
from __future__ import annotations
import os
import sys
import zipfile

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))

import make_release as mr                                                              # noqa: E402

ROOT = mr.ROOT


def test_every_required_path_actually_exists():
    """A manifest that names a file the project does not have is worse than no manifest: it passes the check
    only because nobody ran it. This is the test that found `config/motor_database.yaml` in a doc."""
    missing = [r for r in mr.REQUIRED if not os.path.exists(os.path.join(ROOT, r))]
    assert not missing, f"REQUIRED names files that do not exist: {missing}"


def test_every_required_directory_actually_has_something_in_it():
    empty = []
    for d in mr.REQUIRED_DIRS:
        full = os.path.join(ROOT, d)
        if not os.path.isdir(full) or not os.listdir(full):
            empty.append(d)
    assert not empty, f"REQUIRED_DIRS names directories that are missing or empty: {empty}"


def test_the_tree_as_it_stands_would_make_a_working_archive():
    keep, _skip = mr.collect()
    problems = mr.verify(keep)
    assert not problems, "the project would not package into a working copy: " + "; ".join(problems)


def test_residuals_are_recognised_as_residuals():
    for rel, what in [
        ("src/launch_vehicle/__pycache__/webgui.cpython-313.pyc", "compiled bytecode"),
        ("src/launch_vehicle/webgui.pyc", "a stray .pyc"),
        ("designs/.drafts/whatever-123.yaml", "an unsaved GUI draft"),
        ("outputs/design_report.html", "a generated report"),
        ("outputs/cad/stage1.stl", "a generated CAD file"),
        ("designs/my-rocket.yaml", "somebody's saved design"),
        ("notes.log", "a run log"),
        ("config/default_design.yaml.part", "a half-written save"),
    ]:
        assert mr.dropped(rel), f"{what} ({rel}) would have been shipped"


def test_the_tool_itself_is_not_mistaken_for_a_residual():
    for rel in ("src/launch_vehicle/webgui.py", "src/launch_vehicle/gui_static/index.html",
                "config/default_design.yaml", "examples/example_solid_smallsat.yaml",
                "validation/falcon9.yaml" if os.path.exists(os.path.join(ROOT, "validation/falcon9.yaml"))
                else next(f"validation/{f}" for f in sorted(os.listdir(os.path.join(ROOT, "validation")))
                          if f.endswith(".yaml")),
                "docs/USER_MANUAL.md", "tools/gui.py", "tests/test_stage_count.py",
                "outputs/README.txt", "designs/README.txt", "LICENSE", "pyproject.toml"):
        assert not mr.dropped(rel), f"{rel} would have been left out: {mr.dropped(rel)}"


def test_the_archive_it_writes_opens_and_is_complete():
    import tempfile
    out = os.path.join(tempfile.mkdtemp(), "release.zip")
    rc = mr.main(["--out", out, "--quiet"])
    assert rc == 0, "make_release reported a problem"
    assert os.path.exists(out)
    stem = f"launch_vehicle_sizing-{mr.version()}"
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None, "the archive is corrupt"
        names = z.namelist()
    assert all(n.startswith(stem + "/") for n in names), "the archive does not unpack into one folder"
    inner = {n[len(stem) + 1:] for n in names}
    for r in mr.REQUIRED:
        assert r in inner, f"the written archive is missing {r}"
    assert not any("__pycache__" in n or n.endswith(".pyc") for n in inner), "bytecode shipped"
    os.unlink(out)


def test_the_packager_notices_an_unfilled_copyright_holder():
    """An all-rights-reserved licence with a placeholder where the holder should be reserves nothing. Only
    the owner can fill that in, so it is a warning the packager must RAISE every time rather than a value
    this project can invent - and this test is that the warning works, on both a filled and an unfilled
    licence, so it cannot quietly stop firing once the name is in."""
    assert mr.licence_warning("Copyright (c) 2026 <COPYRIGHT HOLDER>\nAll rights reserved.")
    assert not mr.licence_warning("Copyright (c) 2026 A. Real Name\nAll rights reserved.")
    # and it is wired into the real archive path, on whatever the LICENSE currently says
    with open(os.path.join(ROOT, "LICENSE"), encoding="utf-8") as fh:
        text = fh.read()
    assert "All rights reserved" in text, "the licence is not the one this project ships under"
    expected = "<COPYRIGHT HOLDER>" in text or ("<" in text.split("\n")[0] and ">" in text.split("\n")[0])
    assert bool(mr.licence_warning(text)) == expected, (
        "the warning does not agree with what the licence actually says")


def test_the_version_is_the_same_in_every_place_that_states_it():
    """Three files state the version and the archive is named from one of them. A README whose title says
    v0.23.1 on a v0.24.0 archive is the kind of thing nobody notices until a user reports a bug against the
    wrong release."""
    import re
    with open(os.path.join(ROOT, "pyproject.toml"), encoding="utf-8") as fh:
        proj = re.search(r'^version\s*=\s*"([^"]+)"', fh.read(), re.M).group(1)
    with open(os.path.join(ROOT, "src", "launch_vehicle", "__init__.py"), encoding="utf-8") as fh:
        pkg = re.search(r'^__version__\s*=\s*"([^"]+)"', fh.read(), re.M).group(1)
    with open(os.path.join(ROOT, "README.md"), encoding="utf-8") as fh:
        readme = re.search(r"\(v([0-9][^)]*)\)", fh.readline()).group(1)
    assert proj == pkg == readme, (
        f"version disagreement: pyproject {proj}, package {pkg}, README title {readme}")
    assert mr.version() == proj, "the archive would be named from a different version than pyproject states"


def test_the_changelog_covers_the_version_being_released():
    with open(os.path.join(ROOT, "README.md"), encoding="utf-8") as fh:
        text = fh.read()
    assert f"v{mr.version()}" in text, (
        f"README has no entry for v{mr.version()} - a release with no note saying what changed in it")
