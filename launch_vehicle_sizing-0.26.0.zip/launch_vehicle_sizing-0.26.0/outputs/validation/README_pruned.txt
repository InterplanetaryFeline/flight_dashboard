Per-vehicle design reports and drawings were removed from this archive to keep it inside the
30 MiB transfer limit. What remains for each vehicle is its design_used.yaml, workbook, CSV
tables and run_summary.json - everything needed to check a number or reproduce the run.

To regenerate the full set, including every report and drawing:

    PYTHONPATH=src python tools/run_validation.py

The summary tables that the validation report quotes are kept in full at
outputs/validation/validation_summary.csv and docs/VALIDATION_REPORT.md.
