Some generated artefacts were removed from this archive to keep it inside the 30 MiB transfer
limit. Nothing in the source tree, the configuration or the tests is affected - only outputs,
every one of which regenerates from the command line.

Removed, and how to get each one back:

  outputs/validation/*/design_report.html and drawings
      PYTHONPATH=src python tools/run_validation.py

  outputs/{example_3stage,boosters,solid,enginedb}/design_report.pdf
      PYTHONPATH=src python -m launch_vehicle.main run --design examples/<file>.yaml \
          --out outputs/<name> --all-studies --pdf

Kept in full: the default design's report and PDF, the CAD export, the workbook, the two-vehicle
propellant comparison in outputs/compare/ with both designs' own reports, and every CSV and
run_summary.json in the validation set.
