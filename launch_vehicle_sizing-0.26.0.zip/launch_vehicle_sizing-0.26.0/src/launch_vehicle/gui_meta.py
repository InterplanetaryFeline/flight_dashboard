"""What the GUI needs to show an input as something a person can answer, rather than a YAML path.

Three things, for every one of the ~250 annotated inputs:

* a **label** - "Vacuum specific impulse", not `stages.0.engine.isp_vac_s`;
* the **choices**, where the field has a fixed set. Typing `RP-1` by hand risks a typo, or worse a propellant
  the tool has no density for; a list cannot be mistyped. The lists are not duplicated here - the propellant,
  combination, engine and material ones are read live from the libraries themselves, so a propellant added to
  the assumptions file appears in the GUI without anyone editing this module, and the code-level ones cite the
  line that enforces them;
* a **place**: a section, and a topic within it.

Paths are normalised before matching, so `stages.0.engine.isp_vac_s` and `stages.3.engine.isp_vac_s` both look
up `stages.*.engine.isp_vac_s`. Lookup falls back to the leaf key, then to a prettifier, so a field added to
the YAML without being listed here still gets a readable label rather than breaking the page.
"""
from __future__ import annotations

import os
import re

# --------------------------------------------------------------------------- choices fixed in code
#: path -> [(value, label)]. Every list here is enforced somewhere in the model; the comment says where, so a
#: list that drifts from its validator is a visible mistake rather than a silent one.
def _casing_choices():
    """Solid casing/inert methods, drawn from solid_inert so the GUI and the validator cannot drift.

    The book's four come first because they are the defaults; the published stage-level regressions follow,
    each labelled with the mass it predicts so nobody picks one expecting a casing mass (R18).
    """
    from . import solid_inert
    out = [("book_steel", "Book relation, steel case (motor only)"),
           ("book_composite", "Book relation, composite case (motor only)"),
           ("mass_fraction", "Fraction of propellant (motor only)"),
           ("user_mass", "Mass I give (motor only)")]
    for key, rel in solid_inert.RELATIONS.items():
        scope = "whole stage" if rel.predicts == "stage" else "motor only"
        out.append((key, f"{rel.label} ({scope})"))
    return out


STATIC_CHOICES: dict = {
    # validation.validate_spec
    "mission.orbit.type": [("LEO", "Low Earth orbit"), ("SSO", "Sun-synchronous"),
                           ("GTO", "Geostationary transfer"), ("GEO_VIA_GTO", "Geostationary, via GTO"),
                           ("GEO_DIRECT", "Geostationary, direct"), ("CUSTOM", "Custom (use the fields below)")],
    "mission.losses.model": [("book_penalty", "Book regression (Eq. 3:36-3:38)"),
                             ("book_k1k2", "Book k1/k2 form"), ("book_simple", "Book simple form"),
                             ("user", "My own loss estimates")],
    "vehicle.dv_allocation_mode": [("fractions", "Split by fraction of total"),
                                   ("fixed", "Fixed delta-v per stage")],
    "vehicle.optimise_objective": [("glom", "Lightest vehicle (lift-off mass)"),
                                   ("cost", "Lowest development cost"),
                                   ("payload", "Most payload at the same lift-off mass")],
    "vehicle.payload_adapter_method": [("auto", "Automatic (MER, or fraction for small payloads)"),
                                       ("mer", "Mass relationship (Table 8.8)"),
                                       ("fraction", "Fraction of payload (0.15)")],
    "fairing.material": [("metal", "Metal"), ("composite", "Composite")],
    "stages.*.stage_type": [("liquid", "Liquid"), ("solid", "Solid motor")],
    "stages.*.structure_mode": [("bottom_up", "Build up from components"),
                                ("aggregate_s", "Single structural factor")],
    "stages.*.engine.isp_effective_mode": [("vacuum", "Vacuum Isp"),
                                           ("weighted", "Weighted sea-level/vacuum (Eq. 4:18)"),
                                           ("user", "My own effective Isp")],
    "stages.*.motor.isp_effective_mode": [("vacuum", "Vacuum Isp"),
                                          ("weighted", "Weighted sea-level/vacuum (Eq. 4:18)"),
                                          ("user", "My own effective Isp")],
    "stages.*.engine.geometry_method": [("user", "Dimensions I give"), ("book_mer", "From the book relations")],
    "stages.*.motor.nozzle_geometry_method": [("user", "Dimensions I give"),
                                              ("book_mer", "From the book relations")],
    "stages.*.engine.mass_method": [("mer", "Book mass relationship"),
                                    ("mer_calibrated", "Book relationship x the measured correction"),
                                    ("user", "Mass I give")],
    "stages.*.engine.gimbal_method": [("mer", "Mass relationship"), ("user", "Mass I give"),
                                      ("none", "No separate gimbal mass")],
    "stages.*.tank.arrangement": [("separate", "Separate tanks"), ("common_bulkhead", "Common bulkhead")],
    "stages.*.motor.thrust_mode": [("tw_ignition", "From thrust/weight at ignition"),
                                   ("fixed_thrust", "Fixed thrust"), ("burn_time", "From burn time")],
    "stages.*.motor.casing_mass_method": _casing_choices(),
    "boosters.kind": [("solid", "Solid"), ("liquid", "Liquid")],
    "boosters.inert_mass_method": _casing_choices(),
    "boosters.isp_mode": [("vacuum", "Vacuum Isp"), ("weighted", "Weighted sea-level/vacuum")],
    "mission.wind.kind": [("gust_envelope", "Gust envelope (already contains the gust)"),
                          ("steady", "Steady wind (needs a gust increment)")],
    # the two trajectory-model choices, whose options the design file's own description lists
    "mission.atmosphere_model": [("book_exponential", "Book exponential (Eqs. 6:50/6:53)"),
                                 ("us76", "US 1976 standard atmosphere")],
    "mission.aerodynamics.drag_model": [("book_titan2", "Book Titan II curve (Fig. 6.13)"),
                                        ("constant", "Constant drag coefficient"),
                                        ("table", "Table I supply"),
                                        ("zoom_ld", "ZOOM lift/drag file")],
}
#: tank mass methods come from validation.TANK_METHODS so the two cannot drift apart
_TANK_METHOD_LABELS = {"akin_propellant_mass": "Akin, by propellant mass (Table 8.6)",
                       "akin_volume": "Akin, by volume (Table 8.7)",
                       "pressure_vessel": "Pressure vessel (membrane theory)",
                       "mass_fraction": "Fraction of propellant mass",
                       "user_mass": "Mass I give"}

#: the tank order list is a sequence, not a single choice, but its members are fixed
TANK_ROLES = ("fuel", "oxidizer")


def _tank_method_choices():
    from .validation import TANK_METHODS
    return [(m, _TANK_METHOD_LABELS.get(m, m)) for m in TANK_METHODS]


# --------------------------------------------------------------------------- choices from the libraries
def library_choices(assump: dict | None = None, engine_db_path: str | None = None) -> dict:
    """Choice lists that come from data rather than from code, read live so they cannot go stale.

    A propellant added to engineering_assumptions.yaml, or an engine added to the database, shows up in the
    GUI immediately. Anything unreadable is skipped rather than raising: a broken engine database should cost
    you the engine dropdown, not the whole page.
    """
    out: dict = {}
    if assump:
        props = sorted((assump.get("propellants") or {}))
        combos = sorted((assump.get("propellant_combinations") or {}))
        solids = sorted((assump.get("solid_propellants") or {}))
        mats = sorted((assump.get("tank_materials") or {}))
        if props:
            # Split the library by the role each propellant declares, so the fuel box never offers LOX
            # and the oxidiser box never offers kerosene. A propellant with no role tag is offered in both
            # rather than becoming unreachable - an untagged entry is a gap in the library, not a reason to
            # hide it from the user.
            raw = assump.get("propellants") or {}

            def _role(name):
                try:
                    return ((raw.get(name) or {}).get("role") or {}).get("v")
                except AttributeError:
                    return None
            fuels = [x for x in props if _role(x) in (None, "fuel")]
            oxes = [x for x in props if _role(x) in (None, "oxidizer")]
            for p in ("stages.*.fuel", "boosters.fuel"):
                out[p] = [(x, x) for x in fuels]
            for p in ("stages.*.oxidizer", "boosters.oxidizer"):
                out[p] = [(x, x) for x in oxes]
        if combos:
            out["stages.*.propellant_combination"] = [(x, x) for x in combos]
        # Which tank sits at the bottom. There are exactly two answers, so it is a choice, not a field to
        # type a list into. It keeps its meaning under a common bulkhead: the order still decides which
        # tank is aft, and the book's own S-II example (p.633) shows that moving the heavier tank forward
        # doubled the pre-launch wind running load, from 140.4 to 290.5 kN/m.
        out["stages.*.tank.order_bottom_to_top"] = [
            ("fuel,oxidizer", "Fuel at the bottom, oxidiser above"),
            ("oxidizer,fuel", "Oxidiser at the bottom, fuel above"),
        ]
        if solids:
            out["stages.*.propellant"] = [(x, x) for x in solids]
            out["boosters.propellant"] = [(x, x) for x in solids]
        if mats:
            # Label each key with the material's own name, so the list reads "SS-301-FH - Stainless steel
            # 301, full hard (AMS 5519)" rather than making the user know what a key stands for.
            lib = assump.get("tank_materials") or {}
            def _label(key):
                nm = (lib.get(key) or {}).get("name")
                nm = nm.get("v") if isinstance(nm, dict) else nm
                return f"{key} - {nm}" if nm and nm != key else key
            out["stages.*.tank.material"] = [(x, _label(x)) for x in mats]
    # The launch site library lives in its own file, so it is read whether or not assumptions were passed.
    # A broken library costs the dropdown, not the page: choices() already returns [] on any read failure.
    try:
        from .launch_sites import choices as _site_choices
        sites = _site_choices()
        if sites:
            out["mission.launch_site.site"] = sites
    except Exception:
        pass
    try:
        from . import engine_db
        rows = engine_db.entries(engine_db_path)
        liquid = sorted(e["name"] for e in rows if e.get("kind", "liquid") != "solid")
        solid = sorted(e["name"] for e in rows if e.get("kind") == "solid")
        if liquid:
            out["stages.*.engine.from_database"] = [(x, x) for x in liquid]
        if solid:
            out["stages.*.motor.from_database"] = [(x, x) for x in solid]
            out["boosters.from_database"] = [(x, x) for x in solid]
        cycles = sorted(engine_db.cycles(engine_db_path))
        if cycles:
            out["stages.*.engine.cycle"] = [(c, c.replace("_", " ")) for c in cycles]
    except Exception:                      # a broken database costs the dropdown, not the page
        pass
    for key in ("stages.*.tank.mass_method_fuel", "stages.*.tank.mass_method_oxidizer"):
        out[key] = _tank_method_choices()
    return out


def combination_map(assump: dict | None = None) -> dict:
    """{combination name: {fuel, oxidizer, of_ratio}} for the GUI to apply when a combination is picked.

    Picking "LOX/RP-1" and leaving the fuel box on LH2 is not a design, it is a contradiction - the sizing
    loop resolves the combination and then warns about the disagreement. Better to not create it: the page
    sets the fuel, the oxidiser and the mixture ratio when the combination changes, and shows them as
    ordinary overrides the user can then change on purpose.
    """
    out: dict = {}
    raw = (assump or {}).get("propellant_combinations") or {}
    for name, c in raw.items():
        if not isinstance(c, dict):
            continue

        def _v(key):
            d = c.get(key)
            return d.get("v") if isinstance(d, dict) else d

        of = _v("of_ratio_flight")
        if of is None:
            of = _v("of_ratio_optimum")
        out[name] = {"fuel": _v("fuel"), "oxidizer": _v("oxidizer"), "of_ratio": of}
    return out


#: stage index out of a register path, so a `stages[*]` pattern can be expanded over the real stages
_STAGE_IX = re.compile(r"^stages\[(\d+)\]\.")

#: What a NEW design asks the user for: the design brief, and nothing else.
#:
#: This list is a judgement about how a person starts a vehicle, so it is written down rather than derived.
#: The obvious derivation - "every leaf tagged `provenance: user`" - was tried and is wrong: it picks up
#: `engine.throttle_min_fraction` (1.0, meaning no throttling) and `launch_site.altitude_m` (0.0, sea level),
#: which are defaults that mean something and would come up blank for no reason, and blanking the first makes
#: the design unsizable. What belongs here is what a person has actually decided before they open the tool:
#: what they are launching, to where, from where, and how big a rocket it is going to be. Everything else is
#: the method's business and keeps the value and the provenance it ships with - a new design is a blank brief,
#: not a blank method.
#:
#: `stages[*]` expands over however many stages the design has. Each entry says why it is asked for; the
#: `blank` flag is False for a field that is a pick from a list, because an empty dropdown helps nobody -
#: those are flagged for attention with their default still in place.
NEW_DESIGN_FIELDS: tuple[tuple[str, bool, str], ...] = (
    ("mission.payload_mass_kg", True, "what the vehicle has to lift"),
    ("mission.payload_envelope_diameter_m", True, "how wide the payload is, which drives the fairing"),
    ("mission.payload_envelope_length_m", True, "how long the payload is"),
    ("mission.orbit.type", False, "the kind of orbit; the rest of the orbit block follows from it"),
    ("mission.orbit.perigee_altitude_km", True, "the altitude the payload is injected at"),
    ("mission.orbit.inclination_deg", True, "the inclination asked for; a site cannot go below its latitude"),
    ("mission.launch_site.site", False, "where it flies from; picking one fills the latitude"),
    ("mission.launch_site.latitude_deg", True, "the latitude, if no site from the library fits"),
    ("fairing.diameter_m", True, "the vehicle's outer diameter at the top"),
    ("vehicle.dv_fractions", True, "how the delta-v is split between the stages: the staging decision"),
    ("stages[*].name", False, "what to call the stage"),
    ("stages[*].diameter_m", True, "the stage's diameter"),
    ("stages[*].propellant_combination", False, "what it burns; picking one fills fuel, oxidiser and O/F"),
    ("stages[*].engine.n_engines", True, "how many engines"),
    ("stages[*].engine.isp_vac_s", True, "vacuum specific impulse, or name an engine from the database"),
)


def new_design_plan(items: list) -> dict:
    """Which leaves a new design blanks, and which it merely flags, for the design actually loaded.

    `items` is the described input register, so `stages[*]` is expanded against the stages that exist and a
    pattern naming a leaf this design does not have is dropped rather than reported as missing.
    """
    have = {it["path"] for it in items}
    stage_ix = sorted({int(m.group(1)) for m in
                       (_STAGE_IX.match(p) for p in have) if m})
    blank, flag, unknown = [], [], []
    for pattern, do_blank, why in NEW_DESIGN_FIELDS:
        paths = ([pattern.replace("stages[*]", f"stages[{i}]") for i in stage_ix]
                 if "stages[*]" in pattern else [pattern])
        for p in paths:
            if p not in have:
                unknown.append(p)
                continue
            (blank if do_blank else flag).append({"path": p, "why": why})
    return {"blank": blank, "flag": flag, "missing": unknown}


def launch_site_map() -> dict:
    """{site name: {latitude, min inclination, and the hint text}} for the GUI to apply when a site is picked.

    Latitude is the only design leaf a site may write. The rest is advice the page shows beside the field:
    above all the inclination FLOOR, because the default design sits at 28.5 deg inclination from a 28.5 deg
    latitude and picking the real KSC pad (28.6082 deg) puts the mission 0.1 deg below its own floor. The
    page lifts the inclination to the floor and says it did, rather than letting the user press Size and get
    an infeasibility they did not cause on purpose.
    """
    try:
        from .launch_sites import cascade_map
        raw = cascade_map()
    except Exception:
        return {}
    out: dict = {}
    for name, d in raw.items():
        lat = d["mission.launch_site.latitude_deg"]
        lon = d.get("_longitude_deg")
        floor = d["_min_inclination_deg"]
        where = f"{abs(lat):.4f} deg {'N' if lat >= 0 else 'S'}"
        if lon is not None:
            where += f", {abs(lon):.4f} deg {'E' if lon >= 0 else 'W'}"
        out[name] = {
            "leaves": {"mission.launch_site.latitude_deg": lat},
            "min_inclination_deg": floor,
            "country": d.get("_country") or "",
            "hint": (f"{where}. A direct ascent from here cannot reach an inclination below "
                     f"{floor:.2f} deg; range-safety azimuth limits are not modelled."),
            "source": d.get("_source") or "",
        }
    return out


def choices_for(path: str, lib: dict | None = None):
    """The choice list for one input path, or None if it is a free value."""
    n = normalise(path)
    if lib and n in lib:
        return lib[n]
    return STATIC_CHOICES.get(n)


# --------------------------------------------------------------------------- labels
def normalise(path: str) -> str:
    """Collapse the stage index so one entry covers every stage.

    The input register writes an indexed path as `stages[0].engine.isp_vac_s`, while override paths and the
    design dictionary use `stages.0.engine.isp_vac_s`. Both normalise to `stages.*.engine.isp_vac_s`, so this
    module does not care which spelling it is handed - and neither does the caller.
    """
    t = re.sub(r"\[(\d+)\]", r".\1", str(path))
    return re.sub(r"\.\d+(?=\.|$)", ".*", t)


#: leaf key -> label. Covers the inputs a person actually sets; anything missing falls back to the prettifier.
LEAF_LABELS: dict = {
    # --- the libraries. Left to the automatic rule these come out as "Density kg", "Tank mer per" and
    # --- "Of ratio optimum", which is how a reader ends up unsure what the number even is.
    "unpressurized_kg_m2": "Unpressurised structure, per square metre",
    "composite_fairing_kg_m2": "Composite fairing, per square metre",
    "wiring_kg_per_m": "Wiring, per metre of vehicle",
    "tank_vol_mer_kg_m3": "Tank mass per cubic metre (metallic)",
    "tank_vol_mer_lh2_kg_m3": "Tank mass per cubic metre (liquid hydrogen)",
    "role": "Used as",
    "density_kg_m3": "Density",
    "rho_kg_m3": "Density",
    "boiling_K": "Normal boiling point",
    "insulation_kg_m2": "Tank insulation, per square metre",
    "tank_mer_per_kg": "Tank mass per kg of this propellant",
    "tank_mer_ref_density": "Density the tank relation is valid at",
    "of_ratio_optimum": "O/F for peak Isp (shifting equilibrium)",
    "of_ratio_optimum_frozen": "O/F for peak Isp (frozen flow)",
    "of_ratio_flight": "O/F as actually flown",
    "isp_ref_s": "Reference Isp (shifting equilibrium)",
    "isp_ref_frozen_s": "Reference Isp (frozen flow)",
    "cstar_ref_mps": "Characteristic velocity c*",
    "c_star_mps": "Characteristic velocity c*",
    "Tc_ref_K": "Chamber temperature",
    "mw_ref_kg_kmol": "Exhaust molecular weight",
    "bulk_sg": "Bulk specific gravity of the mixture",
    "isp_note": "Note on the Isp figures",
    "burn_rate_exponent": "Burn-rate pressure exponent n",
    "alpha_per_K": "Thermal expansion coefficient",
    "sigma_allow_Pa": "Allowable stress",
    "joint_efficiency": "Weld joint efficiency",
    "corrosion_allowance_m": "Corrosion allowance",
    "t_min_m": "Minimum tank wall thickness",
    "t_min_structural_m": "Minimum structural gauge",
    "E_Pa": "Young's modulus",
    "poisson": "Poisson's ratio",

    # mission
    "payload_mass_kg": "Payload mass", "payload_adapter_mass_kg": "Payload adapter mass",
    "payload_envelope_diameter_m": "Payload envelope diameter",
    "payload_envelope_length_m": "Payload envelope length",
    "delta_v_override_mps": "Override the whole delta-v budget",
    "report_apogee_maneuver": "Report the apogee manoeuvre separately",
    "perigee_altitude_km": "Perigee altitude", "apogee_altitude_km": "Apogee altitude",
    "eccentricity": "Eccentricity", "inclination_deg": "Inclination",
    "site": "Launch site", "latitude_deg": "Launch site latitude", "altitude_m": "Launch site altitude",
    "azimuth_deg": "Launch azimuth", "include_earth_rotation": "Credit Earth's rotation",
    "staging_delay_s": "Staging delay", "gravity_mps": "Gravity loss", "drag_mps": "Drag loss",
    "steering_mps": "Steering loss", "other_allowance_mps": "Other allowance",
    "design_margin_fraction": "Delta-v design margin", "model": "Loss model",
    "pad_height_m": "Pad height above ground", "profile": "Wind profile",
    "atmosphere_model": "Atmosphere model", "vertical_rise_s": "Vertical rise before the pitch kick",
    "last_ascent_stage": "Stop the ascent after stage", "drag_model": "Drag model",
    "constant_cd": "Constant drag coefficient", "zoom_ld_file": "ZOOM lift/drag file",
    "gust_increment_mps": "Gust increment", "kind": "Kind",
    "max_dynamic_pressure_Pa": "Maximum dynamic pressure allowed",
    "max_q_alpha_Pa_deg": "Maximum q-alpha allowed", "cost_year": "Cost year",
    "cna_overrides": "Normal-force slope overrides",
    # vehicle, fairing
    "paf_length_over_D": "Adapter height / diameter", "payload_adapter_method": "Payload adapter mass method",
    "dv_allocation_mode": "How to split delta-v", "dv_fractions": "How the delta-v is shared between stages",
    "optimise_dv_split": "Optimise the delta-v split when sizing",
    "optimise_objective": "Optimise towards",
    "dv_fixed_mps": "Fixed delta-v per stage", "diameter_m": "Diameter",
    "nose_length_over_D": "Nose length / diameter", "axial_clearance_m": "Axial clearance",
    "radial_clearance_m": "Radial clearance", "material": "Material",
    "jettison_at_stage_start": "Jettison at the start of stage", "mass_override_kg": "Override the mass",
    # constraints
    "max_vehicle_length_m": "Maximum length", "min_tw_liftoff": "Minimum lift-off thrust/weight",
    "max_accel_g": "Maximum axial acceleration", "min_tw_upper": "Minimum upper-stage thrust/weight",
    # stage
    "name": "Name", "fuel": "Fuel", "oxidizer": "Oxidizer", "propellant": "Propellant",
    "propellant_combination": "Propellant combination", "mixture_ratio_OF": "Mixture ratio (oxidiser/fuel)",
    "residual_fraction": "Residual propellant", "loading_margin_fraction": "Loading margin",
    "startup_time_s": "Engine start-up time", "structure_mode": "How to estimate structure",
    "structural_factor_s": "Structural factor s", "stage_type": "Stage type",
    "feed_system_mass_per_engine_kg": "Feed system mass per engine",
    "pressurant_mass_fraction_of_propellant": "Pressurant mass fraction",
    "separation_hardware_mass_kg": "Separation hardware mass",
    "other_equipment_mass_kg": "Other equipment mass",
    "structure_mass_factor": "Structure mass factor", "inert_mass_margin_fraction": "Inert mass margin",
    # layout
    "aft_skirt_over_D": "Aft skirt length / diameter", "intertank_over_D": "Intertank length / diameter",
    "fwd_skirt_over_D": "Forward skirt length / diameter", "interstage_min_length_m": "Minimum interstage length",
    "interstage_clearance_m": "Interstage clearance", "interstage_half_angle_deg": "Transition half-angle",
    # tank
    "arrangement": "Tank arrangement", "order_bottom_to_top": "Tank order, bottom to top",
    "dome_aspect_ratio": "Dome aspect ratio", "ullage_fuel": "Ullage, fuel tank",
    "ullage_oxidizer": "Ullage, oxidiser tank", "mass_method_fuel": "Fuel tank mass method",
    "mass_method_oxidizer": "Oxidiser tank mass method", "wall_thickness_assumed_m": "Assumed wall thickness",
    "pressure_fuel_Pa": "Fuel tank pressure", "pressure_oxidizer_Pa": "Oxidiser tank pressure",
    "mass_fraction_fuel": "Fuel tank mass fraction", "mass_fraction_oxidizer": "Oxidiser tank mass fraction",
    "load_temperature_K": "Loading temperature", "insulated_fuel": "Insulate the fuel tank",
    "insulated_oxidizer": "Insulate the oxidiser tank",
    # engine / motor
    "from_database": "Pick a real engine", "n_engines": "Number of engines", "n_motors": "Number of motors",
    "thrust_to_weight_ignition": "Thrust/weight at ignition",
    "thrust_vac_per_engine_N": "Vacuum thrust per engine", "thrust_vac_total_N": "Total vacuum thrust",
    "isp_vac_s": "Vacuum specific impulse", "isp_sl_s": "Sea-level specific impulse",
    "isp_effective_mode": "Which Isp to use", "isp_sl_weight": "Weight on sea-level Isp",
    "isp_effective_user_s": "Effective Isp I give", "expansion_ratio": "Nozzle area ratio",
    "chamber_pressure_Pa": "Chamber pressure", "length_m": "Length", "exit_diameter_m": "Nozzle exit diameter",
    "embed_fraction": "Fraction embedded in the skirt", "mass_method": "Engine mass method",
    "mass_user_per_engine_kg": "Engine mass", "gimbal_method": "Gimbal mass method",
    "gimbal_user_per_engine_kg": "Gimbal mass", "throttle_min_fraction": "Minimum throttle",
    "geometry_method": "Engine geometry method", "cstar_mps": "Characteristic velocity c*",
    "cycle": "Power cycle", "burn_time_s": "Burn time", "thrust_mode": "How to set thrust",
    "nozzle_length_m": "Nozzle length", "nozzle_geometry_method": "Nozzle geometry method",
    "casing_mass_method": "Casing mass method", "casing_mass_fraction": "Casing mass fraction",
    "casing_mass_kg": "Casing mass", "casing_volume_factor": "Casing volume factor",
    "igniter_mass_kg": "Igniter mass", "tvc_mass_kg": "Thrust-vector-control mass",
    # boosters
    "n_total": "Number of boosters", "n_ground_lit": "Number lit on the ground",
    "attach_stage": "Attached to stage", "prop_mass_each_kg": "Propellant mass each",
    "inert_mass_method": "Inert mass method", "inert_mass_fraction": "Inert mass fraction",
    "inert_mass_each_kg": "Inert mass each", "inert_margin_fraction": "Inert mass margin",
    "base_z_offset_m": "Base height above the core's nozzles", "radial_gap_m": "Radial gap to the core",
    "attach_hw_mass_each_kg": "Attachment hardware mass each", "dome_AR": "Dome aspect ratio",
    "wall_t_assumed_m": "Assumed wall thickness", "of_ratio": "Mixture ratio (oxidiser/fuel)",
    "isp_mode": "Which Isp to use", "isp_weight_sl": "Weight on sea-level Isp",
}

#: a few fields need their section's context to be unambiguous
PATH_LABELS: dict = {
    "fairing.diameter_m": "Fairing diameter",
    "mission.orbit.type": "Orbit type",
    "stages.*.diameter_m": "Stage diameter",
    "stages.*.engine.name": "Engine name",
    "stages.*.motor.name": "Motor name",
    "boosters.name": "Booster name",
    "boosters.diameter_m": "Booster diameter",
    "boosters.exit_diameter_m": "Booster nozzle exit diameter",
    "boosters.nozzle_length_m": "Booster nozzle length",
    "boosters.burn_time_s": "Booster burn time",
    "boosters.residual_fraction": "Booster residual propellant",
    "mission.wind.profile": "Winds-aloft profile",
}

_UNIT_SUFFIX = re.compile(r"_(kg|m|s|n|pa|deg|k|km|mps|m2|m3|kgs|g|usd|wyr)$", re.I)


def label_for(path: str) -> str:
    """A human label for an input path. Never fails: an unlisted field still gets something readable."""
    n = normalise(path)
    if n in PATH_LABELS:
        return PATH_LABELS[n]
    leaf = n.rsplit(".", 1)[-1]
    if leaf in LEAF_LABELS:
        return LEAF_LABELS[leaf]
    pretty = _UNIT_SUFFIX.sub("", leaf).replace("_", " ").strip()
    return (pretty[:1].upper() + pretty[1:]) if pretty else leaf


# --------------------------------------------------------------------------- where an input belongs
#: Library blocks whose second path element is the name of the thing being described. Each one becomes its
#: own section, and each entry inside it its own fold, so "LOX/RP-1" and its mixture ratios stay together.
_LIBRARY_SECTIONS = (
    ("propellant_combinations", "Propellant combinations"),
    ("propellants", "Propellant library"),
    ("solid_propellants", "Solid propellant library"),
    ("tank_materials", "Material library"),
)

#: within a stage, which topic a sub-path belongs to
_STAGE_TOPICS = (("engine.", "Engine"), ("motor.", "Motor"), ("tank.", "Tankage"), ("layout.", "Layout"))
#: the topic holding the one control that decides what the rest of the stage even means. It is its own
#: topic, and `order_for_display` lifts it to the top of the stage, because liquid-or-solid governs which
#: of the other topics apply at all: a solid stage has a motor and no tanks, a liquid one the reverse.
#: Buried nineteen rows down inside "Propellants and size" it read as a detail, which it is not.
_SHAPE_TOPIC = "What kind of stage"
_MISSION_TOPICS = (("orbit.", "Orbit"), ("launch_site.", "Launch site"), ("losses.", "Ascent losses"),
                   ("wind.", "Winds aloft"), ("aerodynamics.", "Trajectory model"))
#: mission fields that describe how the ascent is flown rather than what the mission is
_TRAJECTORY_KEYS = ("atmosphere_model", "vertical_rise_s", "last_ascent_stage", "pad_height_m",
                    "max_dynamic_pressure_Pa", "max_q_alpha_Pa_deg")
_STAGE_MASS_KEYS = ("feed_system_mass_per_engine_kg", "pressurant_mass_fraction_of_propellant",
                    "separation_hardware_mass_kg", "other_equipment_mass_kg", "structure_mass_factor",
                    "inert_mass_margin_fraction", "structure_mode", "structural_factor_s")


def place(path: str) -> tuple:
    """(section, topic) for an input path. The section is the big heading, the topic the fold inside it."""
    n = normalise(path)
    # work on the dotted spelling throughout, so stages[0]. and stages.0. route identically
    p = re.sub(r"\[(\d+)\]", r".\1", str(path))
    if p.startswith("mission."):
        rest = p[len("mission."):]
        for pre, topic in _MISSION_TOPICS:
            if rest.startswith(pre):
                return "Mission", topic
        if rest in _TRAJECTORY_KEYS:
            return "Mission", "Trajectory model"
        return "Mission", "Payload and orbit"
    if p.startswith("fairing."):
        return "Payload fairing", "Fairing"
    if p.startswith("vehicle."):
        return "Vehicle", "Staging and adapter"
    if p.startswith("constraints."):
        return "Limits to respect", "Limits"
    if p.startswith("boosters."):
        return "Strap-on boosters", "Boosters"
    if p.startswith("stages."):
        try:
            idx = int(p.split(".")[1]) + 1
        except (IndexError, ValueError):
            return "Stages", "Stage"
        rest = p.split(".", 2)[2] if len(p.split(".", 2)) > 2 else ""
        if rest == "stage_type":
            return f"Stage {idx}", _SHAPE_TOPIC
        for pre, topic in _STAGE_TOPICS:
            if rest.startswith(pre):
                return f"Stage {idx}", topic
        if rest in _STAGE_MASS_KEYS:
            return f"Stage {idx}", "Mass estimating"
        return f"Stage {idx}", "Propellants and size"
    # Library blocks are keyed by the thing they describe, so each entry gets its OWN fold. Flattened into
    # one topic they are unusable: the propellant library alone is 75 rows with "Density" appearing fifteen
    # times, and the combinations 132 rows with no way to tell which O/F belongs to which pair. A user who
    # scrolls to the first "Density" and reads its description sees LOX's, and reasonably concludes the tank
    # is always sized for LOX - which it is not.
    for prefix, section in _LIBRARY_SECTIONS:
        if p.startswith(prefix + "."):
            rest = p[len(prefix) + 1:]
            name = rest.split(".", 1)[0] if "." in rest else rest
            return section, name or section
    return "Modelling assumptions", n.split(".", 1)[0].replace("_", " ").title()


#: sections shown expanded when the page first loads; the rest start folded.
#: NOTE: this names Stage 1 and Stage 2 only because it was written when every design had two stages. Use
#: `open_sections_for`, which adds whatever stages the design actually has - a hardcoded pair left a
#: three-stage design opening with its third stage folded away, and a stage added with the stage-count
#: control arriving collapsed, with the fields the user was just told to fill hidden behind a disclosure.
OPEN_SECTIONS = ("Mission", "Stage 1", "Stage 2", "Payload fairing", "Limits to respect")


def open_sections_for(items: list) -> list:
    """The sections to show expanded for THIS design: the fixed set, plus every stage it has.

    The stages are the design. A vehicle with six of them should not open with four of them hidden.
    """
    out = list(OPEN_SECTIONS)
    for it in items:
        sec = it.get("section") or ""
        if sec.startswith("Stage ") and sec not in out:
            out.append(sec)
    return out


def describe_inputs(items: list, assump: dict | None = None) -> list:
    """Attach label, choices, section and topic to each register row, in place-friendly form."""
    lib = library_choices(assump)
    out = []
    for it in items:
        section, topic = place(it["path"])
        ch = choices_for(it["path"], lib)
        row = dict(it)
        row.update(label=label_for(it["path"]), section=section, topic=topic,
                   choices=[{"value": v, "label": lab} for v, lab in ch] if ch else None)
        out.append(row)
    return order_for_display(out)


def order_for_display(rows: list) -> list:
    """Put the shape-deciding control at the top of its stage, leaving everything else as it was.

    The GUI groups by section and then by topic in the order the rows arrive, so a row's position in this
    list is its position on the page. `stage_type` arrives from the register wherever the YAML happens to
    list it - row 19 of Stage 1 on the check cases, below the whole "Mass estimating" topic. It decides
    whether the stage has an engine and tanks or a motor and a casing, so it goes first; the sort is stable,
    so nothing else moves relative to anything else.
    """
    order = {}
    for i, r in enumerate(rows):
        sec = r.get("section") or ""
        if sec not in order:
            order[sec] = i
    def key(pair):
        i, r = pair
        sec = r.get("section") or ""
        return (order[sec], 0 if r.get("topic") == _SHAPE_TOPIC else 1, i)
    return [r for _, r in sorted(enumerate(rows), key=key)]
