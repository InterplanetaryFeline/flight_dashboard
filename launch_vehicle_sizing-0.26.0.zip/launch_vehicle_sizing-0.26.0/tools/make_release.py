"""Build the release archive, and prove it is the whole tool and nothing else.

Packaging had been done by hand, which is how a zip ends up carrying somebody's `__pycache__`, a half-written
GUI draft and last week's generated report. This script makes it repeatable and, more usefully, makes it
CHECKED: it refuses to write an archive that is missing something the tool needs to run, and it refuses to
write one that carries a residual.

    python tools/make_release.py                       # -> outputs/launch_vehicle_sizing-<version>.zip
    python tools/make_release.py --out /tmp/x.zip
    python tools/make_release.py --check               # say what would go in, write nothing

What counts as a residual is listed in EXCLUDE below, with the reason. The principle is that the archive
contains what a person needs to RUN and READ the tool - source, configuration, designs, docs, tests, the
validation cases - and nothing that the tool itself produced. Generated outputs are reproducible by running
the tool; shipping them invites someone to read a stale number as a current one.
"""
from __future__ import annotations
import argparse
import os
import re
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

#: directory names dropped wherever they appear, with why
EXCLUDE_DIRS = {
    "__pycache__": "compiled bytecode, rebuilt on first import",
    ".pytest_cache": "test-runner scratch",
    ".git": "version-control metadata",
    ".ipynb_checkpoints": "notebook scratch",
    ".drafts": "unsaved GUI working drafts - someone's half-finished design, not part of the tool",
    ".mypy_cache": "type-checker scratch",
    "node_modules": "not used by this tool",
    ".venv": "a virtual environment is per-machine",
    "venv": "a virtual environment is per-machine",
    "gui_test": "scratch directory the GUI tests write into",
}

#: file patterns dropped wherever they appear
EXCLUDE_FILES = [
    (re.compile(r"\.pyc$"), "compiled bytecode"),
    (re.compile(r"\.pyo$"), "compiled bytecode"),
    (re.compile(r"^\.DS_Store$"), "macOS folder metadata"),
    (re.compile(r"^Thumbs\.db$"), "Windows thumbnail cache"),
    (re.compile(r"\.swp$|~$"), "editor scratch"),
    (re.compile(r"^\.coverage"), "coverage scratch"),
    (re.compile(r"\.part$"), "a half-written file from an interrupted save"),
    (re.compile(r"\.log$"), "run logs"),
]

#: `outputs/` is where the tool WRITES. Nothing generated ships; the two READMEs that explain the directory
#: do, so the folder arrives with an explanation rather than empty and mysterious.
OUTPUTS_KEEP = {"README.txt", "README_pruned.txt", "PRUNED.txt"}

#: what the archive must contain, or it is not a working copy of the tool
REQUIRED = [
    "README.md", "LICENSE", "pyproject.toml", "requirements.txt",
    "src/launch_vehicle/__init__.py", "src/launch_vehicle/webgui.py",
    "src/launch_vehicle/convergence.py", "src/launch_vehicle/stage_count.py",
    "src/launch_vehicle/strap_ons.py", "src/launch_vehicle/boosters.py",
    "src/launch_vehicle/optimization.py", "docs/OPTIMISATION.md",
    "src/launch_vehicle/gui_static/index.html",
    "config/default_design.yaml", "config/engineering_assumptions.yaml",
    "config/engine_database.yaml", "config/launch_sites.yaml",
    "tools/gui.py", "tools/run_tests.py",
    "docs/USER_MANUAL.md", "docs/ACCURACY.md",
]

#: directories that must arrive with something in them
REQUIRED_DIRS = ["src/launch_vehicle", "config", "docs", "tests", "tools", "examples", "validation",
                 "tools/mini_pytest"]


def version() -> str:
    try:
        with open(os.path.join(ROOT, "pyproject.toml"), encoding="utf-8") as fh:
            m = re.search(r'^version\s*=\s*"([^"]+)"', fh.read(), re.M)
        if m:
            return m.group(1)
    except OSError:
        pass
    return "0"


def licence_warning(text: str) -> str | None:
    """Whether the licence still has a placeholder where the copyright holder's name belongs.

    This is a warning and not an error, deliberately. An all-rights-reserved licence naming
    `<COPYRIGHT HOLDER>` reserves rights for nobody, so it must be said loudly on every build - but the name
    is the owner's to supply and is not something this script, or anyone else, should invent on their behalf.
    So the archive is still written, with the gap stated.
    """
    first = text.split("\n", 1)[0]
    if "<COPYRIGHT HOLDER>" in text or ("<" in first and ">" in first):
        return ("LICENSE still has a placeholder where the copyright holder's name goes. An "
                "all-rights-reserved licence that names nobody reserves nothing - put the name or "
                "organisation in before this archive goes anywhere.")
    return None


def dropped(rel: str) -> str | None:
    """Why this path is not in the archive, or None to include it."""
    parts = rel.split("/")
    for p in parts[:-1]:
        if p in EXCLUDE_DIRS:
            return EXCLUDE_DIRS[p]
    if parts[-1] in EXCLUDE_DIRS:
        return EXCLUDE_DIRS[parts[-1]]
    for pat, why in EXCLUDE_FILES:
        if pat.search(parts[-1]):
            return why
    if parts[0] == "outputs" and parts[-1] not in OUTPUTS_KEEP:
        return "generated output - reproducible by running the tool, and stale the moment an input changes"
    if parts[0] == "designs" and parts[-1] != "README.txt":
        return "a saved design belongs to whoever saved it, not to the release"
    return None


def collect():
    keep, skip = [], {}
    for base, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for f in files:
            rel = os.path.relpath(os.path.join(base, f), ROOT).replace(os.sep, "/")
            why = dropped(rel)
            if why:
                skip.setdefault(why, []).append(rel)
            else:
                keep.append(rel)
    return sorted(keep), skip


def verify(keep: list) -> list:
    """Everything the archive must have. Returns the complaints; an empty list means it is a working copy."""
    have = set(keep)
    problems = [f"MISSING {r}" for r in REQUIRED if r not in have]
    for d in REQUIRED_DIRS:
        if not any(k.startswith(d + "/") for k in have):
            problems.append(f"MISSING everything under {d}/")
    # a residual that slipped through the filter is as much a defect as a missing file
    for k in have:
        if "__pycache__" in k or k.endswith(".pyc"):
            problems.append(f"RESIDUAL {k}")
    # every design the GUI offers as a starting point has to actually be in the archive
    for d in ("config", "examples", "validation"):
        n = sum(1 for k in have if k.startswith(d + "/") and k.endswith((".yaml", ".yml")))
        if not n:
            problems.append(f"MISSING every YAML under {d}/")
    return problems


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", default=None, help="where to write the zip")
    ap.add_argument("--check", action="store_true", help="report only; write nothing")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args(argv)

    keep, skip = collect()
    problems = verify(keep)

    if not a.quiet:
        n_skip = sum(len(v) for v in skip.values())
        print(f"{len(keep)} files to ship, {n_skip} left out\n")
        for why, paths in sorted(skip.items(), key=lambda kv: -len(kv[1])):
            print(f"  {len(paths):4d}  {why}")
            for p in sorted(paths)[:3]:
                print(f"        e.g. {p}")
        print()
        by_top = {}
        for k in keep:
            by_top[k.split("/")[0]] = by_top.get(k.split("/")[0], 0) + 1
        print("  shipping: " + ", ".join(f"{d} ({n})" for d, n in sorted(by_top.items(), key=lambda kv: -kv[1])))
        print()

    if problems:
        print("THE ARCHIVE WOULD NOT BE A WORKING COPY:")
        for p in problems:
            print("  " + p)
        return 1
    print("every required file and directory is present, and no residual slipped through")

    try:
        with open(os.path.join(ROOT, "LICENSE"), encoding="utf-8") as fh:
            warn = licence_warning(fh.read())
    except OSError:
        warn = "there is no LICENSE file at all"
    if warn:
        print("\n  !! " + warn)

    if a.check:
        return 0

    out = a.out or os.path.join(ROOT, "outputs", f"launch_vehicle_sizing-{version()}.zip")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    stem = f"launch_vehicle_sizing-{version()}"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in keep:
            z.write(os.path.join(ROOT, rel), f"{stem}/{rel}")
    size = os.path.getsize(out)
    print(f"\nwrote {out}  ({size / 1e6:.1f} MB, {len(keep)} files, top level {stem}/)")

    # read it back: an archive nobody opened is an archive nobody knows is good
    with zipfile.ZipFile(out) as z:
        bad = z.testzip()
        names = {n[len(stem) + 1:] for n in z.namelist()}
    if bad:
        print(f"ARCHIVE IS CORRUPT at {bad}")
        return 1
    missing = [r for r in REQUIRED if r not in names]
    if missing:
        print("THE WRITTEN ARCHIVE IS MISSING: " + ", ".join(missing))
        return 1
    print("re-opened and checked: not corrupt, and every required file is in it")
    return 0


if __name__ == "__main__":
    sys.exit(main())
